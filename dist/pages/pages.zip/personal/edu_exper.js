'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _api = require('./../../api/api.js');

var _api2 = _interopRequireDefault(_api);

var _tip = require('./../../utils/tip.js');

var _tip2 = _interopRequireDefault(_tip);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BaseInfo = function (_wepy$page) {
    _inherits(BaseInfo, _wepy$page);

    function BaseInfo() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, BaseInfo);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = BaseInfo.__proto__ || Object.getPrototypeOf(BaseInfo)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: '教育经历'
        }, _this.data = {
            school: '',
            specialtyid: '',
            starttime: '',
            endtime: '',
            educationbg: [],
            a_educationbg: '',
            educationbgstatus: true,
            index: '',
            educationid: '',
            token: "",
            tokenKey: "",
            resumeid: ''
        }, _this.methods = {
            // 提交表单--基本信息编辑新增
            formSubmit: function formSubmit(e) {
                wx.showLoading({
                    title: '加载中'
                });
                if (this.educationid != "undefined") {
                    e.detail.value.educationid = this.educationid;
                }
                var obj2 = {
                    "token": this.token,
                    "tokenKey": this.tokenKey,
                    "resumeid": this.resumeid
                };
                if (!obj2.resumeid) {
                    delete obj2['resumeid'];
                }
                var that = this;
                this.changeBaseInfo(e.detail.value, obj2).then(function (data) {
                    if (data.data && data.data.returnCode == "AAAAAAA") {
                        wx.redirectTo({
                            url: 'resume?resumeid=' + that.resumeid
                        });
                    } else {
                        console.log(data);
                    }
                    wx.hideLoading();
                });
            },
            bindDateChange1: function bindDateChange1(e) {
                this.starttime = e.detail.value;
                this.$apply();
            },
            bindDateChange2: function bindDateChange2(e) {
                this.endtime = e.detail.value;
                this.$apply();
            },
            bindPickerChange: function bindPickerChange(e) {
                this.educationbgstatus = false;
                this.index = e.detail.value;
                this.$apply();
            }

            //获取教育经历
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(BaseInfo, [{
        key: 'onLoad',
        value: function onLoad(options) {
            this.educationid = options.educationid;
            this.resumeid = options.resumeid;
            this.$apply();
            var that = this;
            // 获取登录信息
            wx.getStorage({
                key: 'loginData',
                success: function success(res) {
                    that.token = res.data.token;
                    that.tokenKey = res.data.tokenKey;
                    that.$apply();
                    //获取求职意向
                    if (options.resumeid == '') {
                        return false;
                    }
                    that.getJobInfo(that.token, that.tokenKey, that.resumeid).then(function (json) {
                        if (json.data.returnCode == "AAAAAAA") {
                            var jobExper = JSON.parse(json.data.data);
                            var resultArr = jobExper.find(function (item) {
                                return item.educationid == options.educationid;
                            });
                            that.school = resultArr.school;
                            that.specialtyid = resultArr.specialtyid;
                            that.starttime = resultArr.starttime;
                            that.endtime = resultArr.endtime;
                            that.a_educationbg = resultArr.educationbg;
                            that.$apply();
                        } else {
                            _tip2.default.error(json.returnMsg);
                        }
                    });
                }
            });

            // 获取数据字典数据
            this.getDict("DICT_JOB_EDU").then(function (json) {
                if (json.data.returnCode == "AAAAAAA") {
                    var arr = [];
                    json.data.data.forEach(function (item, index) {
                        arr.push(item.label);
                    });
                    that.educationbg = arr;
                    that.$apply();
                } else {
                    _tip2.default.error(json.returnMsg);
                }
            });
        }
    }, {
        key: 'getJobInfo',
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(token, tokenKey, resumeid) {
                var json;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _api2.default.getResumeInfo({
                                    query: {
                                        head: {
                                            "transcode": "M0006",
                                            "type": "h"
                                        },
                                        data: {
                                            "token": token,
                                            "tokenKey": tokenKey,
                                            "resumeid": resumeid
                                        }
                                    }
                                });

                            case 2:
                                json = _context.sent;
                                return _context.abrupt('return', json);

                            case 4:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function getJobInfo(_x, _x2, _x3) {
                return _ref2.apply(this, arguments);
            }

            return getJobInfo;
        }()

        //获取数据字典

    }, {
        key: 'getDict',
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(code) {
                var json;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return _api2.default.getDictData({
                                    query: {
                                        head: {
                                            "transcode": "DC001",
                                            "type": "h"
                                        },
                                        data: {
                                            "groupcode": code,
                                            "selAll": "true"
                                        }
                                    }
                                });

                            case 2:
                                json = _context2.sent;
                                return _context2.abrupt('return', json);

                            case 4:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function getDict(_x4) {
                return _ref3.apply(this, arguments);
            }

            return getDict;
        }()

        //修改表单数据

    }, {
        key: 'changeBaseInfo',
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(obj, obj2) {
                var data, resultObj, json;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                data = obj2;
                                resultObj = Object.assign(data, obj);
                                _context3.next = 4;
                                return _api2.default.getResumeInfo({
                                    query: {
                                        head: {
                                            "transcode": "M0016",
                                            "type": "h"
                                        },
                                        data: resultObj
                                    }
                                });

                            case 4:
                                json = _context3.sent;
                                return _context3.abrupt('return', json);

                            case 6:
                            case 'end':
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function changeBaseInfo(_x5, _x6) {
                return _ref4.apply(this, arguments);
            }

            return changeBaseInfo;
        }()
    }]);

    return BaseInfo;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(BaseInfo , 'pages/personal/edu_exper'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVkdV9leHBlci5qcyJdLCJuYW1lcyI6WyJCYXNlSW5mbyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwic2Nob29sIiwic3BlY2lhbHR5aWQiLCJzdGFydHRpbWUiLCJlbmR0aW1lIiwiZWR1Y2F0aW9uYmciLCJhX2VkdWNhdGlvbmJnIiwiZWR1Y2F0aW9uYmdzdGF0dXMiLCJpbmRleCIsImVkdWNhdGlvbmlkIiwidG9rZW4iLCJ0b2tlbktleSIsInJlc3VtZWlkIiwibWV0aG9kcyIsImZvcm1TdWJtaXQiLCJlIiwid3giLCJzaG93TG9hZGluZyIsInRpdGxlIiwiZGV0YWlsIiwidmFsdWUiLCJvYmoyIiwidGhhdCIsImNoYW5nZUJhc2VJbmZvIiwidGhlbiIsInJldHVybkNvZGUiLCJyZWRpcmVjdFRvIiwidXJsIiwiY29uc29sZSIsImxvZyIsImhpZGVMb2FkaW5nIiwiYmluZERhdGVDaGFuZ2UxIiwiJGFwcGx5IiwiYmluZERhdGVDaGFuZ2UyIiwiYmluZFBpY2tlckNoYW5nZSIsIm9wdGlvbnMiLCJnZXRTdG9yYWdlIiwia2V5Iiwic3VjY2VzcyIsInJlcyIsImdldEpvYkluZm8iLCJqc29uIiwiam9iRXhwZXIiLCJKU09OIiwicGFyc2UiLCJyZXN1bHRBcnIiLCJmaW5kIiwiaXRlbSIsImVycm9yIiwicmV0dXJuTXNnIiwiZ2V0RGljdCIsImFyciIsImZvckVhY2giLCJwdXNoIiwibGFiZWwiLCJnZXRSZXN1bWVJbmZvIiwicXVlcnkiLCJoZWFkIiwiY29kZSIsImdldERpY3REYXRhIiwib2JqIiwicmVzdWx0T2JqIiwiT2JqZWN0IiwiYXNzaWduIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUVxQkEsUTs7Ozs7Ozs7Ozs7Ozs7OExBRW5CQyxNLEdBQVM7QUFDVEMsb0NBQXdCO0FBRGYsUyxRQUlUQyxJLEdBQU87QUFDSEMsb0JBQU8sRUFESjtBQUVIQyx5QkFBWSxFQUZUO0FBR0hDLHVCQUFVLEVBSFA7QUFJSEMscUJBQVEsRUFKTDtBQUtIQyx5QkFBYSxFQUxWO0FBTUhDLDJCQUFlLEVBTlo7QUFPSEMsK0JBQW1CLElBUGhCO0FBUUhDLG1CQUFNLEVBUkg7QUFTSEMseUJBQVksRUFUVDtBQVVIQyxtQkFBTyxFQVZKO0FBV0hDLHNCQUFVLEVBWFA7QUFZSEMsc0JBQVM7QUFaTixTLFFBK0RQQyxPLEdBQVU7QUFDTjtBQUNBQyx3QkFBWSxvQkFBU0MsQ0FBVCxFQUFZO0FBQ3BCQyxtQkFBR0MsV0FBSCxDQUFlO0FBQ1hDLDJCQUFPO0FBREksaUJBQWY7QUFHQSxvQkFBRyxLQUFLVCxXQUFMLElBQW9CLFdBQXZCLEVBQW1DO0FBQy9CTSxzQkFBRUksTUFBRixDQUFTQyxLQUFULENBQWVYLFdBQWYsR0FBNkIsS0FBS0EsV0FBbEM7QUFDSDtBQUNELG9CQUFJWSxPQUFPO0FBQ1AsNkJBQVMsS0FBS1gsS0FEUDtBQUVQLGdDQUFZLEtBQUtDLFFBRlY7QUFHUCxnQ0FBWSxLQUFLQztBQUhWLGlCQUFYO0FBS0Esb0JBQUcsQ0FBQ1MsS0FBS1QsUUFBVCxFQUFrQjtBQUNkLDJCQUFPUyxLQUFLLFVBQUwsQ0FBUDtBQUNIO0FBQ0Qsb0JBQU1DLE9BQU8sSUFBYjtBQUNBLHFCQUFLQyxjQUFMLENBQW9CUixFQUFFSSxNQUFGLENBQVNDLEtBQTdCLEVBQW1DQyxJQUFuQyxFQUF5Q0csSUFBekMsQ0FBOEMsZ0JBQU07QUFDaEQsd0JBQUd4QixLQUFLQSxJQUFMLElBQWFBLEtBQUtBLElBQUwsQ0FBVXlCLFVBQVYsSUFBd0IsU0FBeEMsRUFBbUQ7QUFDL0NULDJCQUFHVSxVQUFILENBQWM7QUFDVkMsc0RBQXdCTCxLQUFLVjtBQURuQix5QkFBZDtBQUdILHFCQUpELE1BSUs7QUFDRGdCLGdDQUFRQyxHQUFSLENBQVk3QixJQUFaO0FBQ0g7QUFDRGdCLHVCQUFHYyxXQUFIO0FBQ0gsaUJBVEQ7QUFVSCxhQTVCSztBQTZCTkMsNkJBQWlCLHlCQUFTaEIsQ0FBVCxFQUFZO0FBQ3pCLHFCQUFLWixTQUFMLEdBQWlCWSxFQUFFSSxNQUFGLENBQVNDLEtBQTFCO0FBQ0EscUJBQUtZLE1BQUw7QUFDSCxhQWhDSztBQWlDTkMsNkJBQWlCLHlCQUFTbEIsQ0FBVCxFQUFZO0FBQ3pCLHFCQUFLWCxPQUFMLEdBQWVXLEVBQUVJLE1BQUYsQ0FBU0MsS0FBeEI7QUFDQSxxQkFBS1ksTUFBTDtBQUNILGFBcENLO0FBcUNORSw4QkFBa0IsMEJBQVNuQixDQUFULEVBQVk7QUFDMUIscUJBQUtSLGlCQUFMLEdBQXlCLEtBQXpCO0FBQ0EscUJBQUtDLEtBQUwsR0FBYU8sRUFBRUksTUFBRixDQUFTQyxLQUF0QjtBQUNBLHFCQUFLWSxNQUFMO0FBQ0g7O0FBR0w7QUE1Q1UsUzs7Ozs7K0JBaERIRyxPLEVBQVM7QUFDWixpQkFBSzFCLFdBQUwsR0FBbUIwQixRQUFRMUIsV0FBM0I7QUFDQSxpQkFBS0csUUFBTCxHQUFnQnVCLFFBQVF2QixRQUF4QjtBQUNBLGlCQUFLb0IsTUFBTDtBQUNBLGdCQUFNVixPQUFPLElBQWI7QUFDQTtBQUNBTixlQUFHb0IsVUFBSCxDQUFjO0FBQ1ZDLHFCQUFLLFdBREs7QUFFVkMseUJBQVMsaUJBQVNDLEdBQVQsRUFBYztBQUNuQmpCLHlCQUFLWixLQUFMLEdBQWE2QixJQUFJdkMsSUFBSixDQUFTVSxLQUF0QjtBQUNBWSx5QkFBS1gsUUFBTCxHQUFnQjRCLElBQUl2QyxJQUFKLENBQVNXLFFBQXpCO0FBQ0FXLHlCQUFLVSxNQUFMO0FBQ0E7QUFDQSx3QkFBR0csUUFBUXZCLFFBQVIsSUFBa0IsRUFBckIsRUFBd0I7QUFDdEIsK0JBQU8sS0FBUDtBQUNEO0FBQ0RVLHlCQUFLa0IsVUFBTCxDQUFnQmxCLEtBQUtaLEtBQXJCLEVBQTJCWSxLQUFLWCxRQUFoQyxFQUF5Q1csS0FBS1YsUUFBOUMsRUFBd0RZLElBQXhELENBQTZELGdCQUFRO0FBQ2pFLDRCQUFJaUIsS0FBS3pDLElBQUwsQ0FBVXlCLFVBQVYsSUFBd0IsU0FBNUIsRUFBdUM7QUFDbkMsZ0NBQUlpQixXQUFXQyxLQUFLQyxLQUFMLENBQVdILEtBQUt6QyxJQUFMLENBQVVBLElBQXJCLENBQWY7QUFDQSxnQ0FBSTZDLFlBQVlILFNBQVNJLElBQVQsQ0FBYztBQUFBLHVDQUFRQyxLQUFLdEMsV0FBTCxJQUFvQjBCLFFBQVExQixXQUFwQztBQUFBLDZCQUFkLENBQWhCO0FBQ0FhLGlDQUFLckIsTUFBTCxHQUFjNEMsVUFBVTVDLE1BQXhCO0FBQ0FxQixpQ0FBS3BCLFdBQUwsR0FBbUIyQyxVQUFVM0MsV0FBN0I7QUFDQW9CLGlDQUFLbkIsU0FBTCxHQUFpQjBDLFVBQVUxQyxTQUEzQjtBQUNBbUIsaUNBQUtsQixPQUFMLEdBQWV5QyxVQUFVekMsT0FBekI7QUFDQWtCLGlDQUFLaEIsYUFBTCxHQUFxQnVDLFVBQVV4QyxXQUEvQjtBQUNBaUIsaUNBQUtVLE1BQUw7QUFDSCx5QkFURCxNQVNPO0FBQ0gsMENBQUlnQixLQUFKLENBQVVQLEtBQUtRLFNBQWY7QUFDSDtBQUNKLHFCQWJEO0FBY0g7QUF4QlMsYUFBZDs7QUEyQkE7QUFDQSxpQkFBS0MsT0FBTCxDQUFhLGNBQWIsRUFBNkIxQixJQUE3QixDQUFrQyxnQkFBUTtBQUN0QyxvQkFBSWlCLEtBQUt6QyxJQUFMLENBQVV5QixVQUFWLElBQXdCLFNBQTVCLEVBQXVDO0FBQ25DLHdCQUFJMEIsTUFBTSxFQUFWO0FBQ0FWLHlCQUFLekMsSUFBTCxDQUFVQSxJQUFWLENBQWVvRCxPQUFmLENBQXVCLFVBQUNMLElBQUQsRUFBTXZDLEtBQU4sRUFBYztBQUNqQzJDLDRCQUFJRSxJQUFKLENBQVNOLEtBQUtPLEtBQWQ7QUFDSCxxQkFGRDtBQUdBaEMseUJBQUtqQixXQUFMLEdBQW1COEMsR0FBbkI7QUFDQTdCLHlCQUFLVSxNQUFMO0FBQ0gsaUJBUEQsTUFPTztBQUNILGtDQUFJZ0IsS0FBSixDQUFVUCxLQUFLUSxTQUFmO0FBQ0g7QUFDSixhQVhEO0FBWUg7Ozs7aUdBK0NnQnZDLEssRUFBTUMsUSxFQUFTQyxROzs7Ozs7O3VDQUNULGNBQUkyQyxhQUFKLENBQWtCO0FBQ3JDQywyQ0FBTztBQUNDQyw4Q0FBTTtBQUNGLHlEQUFhLE9BRFg7QUFFRixvREFBUTtBQUZOLHlDQURQO0FBS0N6RCw4Q0FBTTtBQUNGLHFEQUFTVSxLQURQO0FBRUYsd0RBQVlDLFFBRlY7QUFHRix3REFBWUM7QUFIVjtBQUxQO0FBRDhCLGlDQUFsQixDOzs7QUFBYjZCLG9DO2lFQWFDQSxJOzs7Ozs7Ozs7Ozs7Ozs7OztBQUdYOzs7OztrR0FDY2lCLEk7Ozs7Ozs7dUNBQ1MsY0FBSUMsV0FBSixDQUFnQjtBQUNuQ0gsMkNBQU87QUFDQ0MsOENBQU07QUFDRix5REFBYSxPQURYO0FBRUYsb0RBQVE7QUFGTix5Q0FEUDtBQUtDekQsOENBQU07QUFDRix5REFBYTBELElBRFg7QUFFRixzREFBVTtBQUZSO0FBTFA7QUFENEIsaUNBQWhCLEM7OztBQUFiakIsb0M7a0VBWUNBLEk7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBR1g7Ozs7O2tHQUNxQm1CLEcsRUFBSXZDLEk7Ozs7OztBQUNqQnJCLG9DLEdBQU9xQixJO0FBQ1B3Qyx5QyxHQUFZQyxPQUFPQyxNQUFQLENBQWMvRCxJQUFkLEVBQW9CNEQsR0FBcEIsQzs7dUNBQ0csY0FBSUwsYUFBSixDQUFrQjtBQUNyQ0MsMkNBQU87QUFDQ0MsOENBQU07QUFDRix5REFBYSxPQURYO0FBRUYsb0RBQVE7QUFGTix5Q0FEUDtBQUtDekQsOENBQU02RDtBQUxQO0FBRDhCLGlDQUFsQixDOzs7QUFBYnBCLG9DO2tFQVNDQSxJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBakt5QixlQUFLdUIsSTs7a0JBQXRCbkUsUSIsImZpbGUiOiJlZHVfZXhwZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tICd3ZXB5J1xyXG4gIGltcG9ydCBhcGkgZnJvbSAnLi4vLi4vYXBpL2FwaSc7XHJcbiAgaW1wb3J0IHRpcCBmcm9tICcuLi8uLi91dGlscy90aXAnO1xyXG5cclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBCYXNlSW5mbyBleHRlbmRzIHdlcHkucGFnZSB7XHJcblxyXG4gICAgY29uZmlnID0ge1xyXG4gICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogJ+aVmeiCsue7j+WOhicsXHJcbiAgICB9XHJcblxyXG4gICAgZGF0YSA9IHtcclxuICAgICAgICBzY2hvb2w6JycsXHJcbiAgICAgICAgc3BlY2lhbHR5aWQ6JycsXHJcbiAgICAgICAgc3RhcnR0aW1lOicnLFxyXG4gICAgICAgIGVuZHRpbWU6JycsXHJcbiAgICAgICAgZWR1Y2F0aW9uYmc6IFtdLFxyXG4gICAgICAgIGFfZWR1Y2F0aW9uYmc6ICcnLFxyXG4gICAgICAgIGVkdWNhdGlvbmJnc3RhdHVzOiB0cnVlLFxyXG4gICAgICAgIGluZGV4OicnLFxyXG4gICAgICAgIGVkdWNhdGlvbmlkOicnLFxyXG4gICAgICAgIHRva2VuOiBcIlwiLFxyXG4gICAgICAgIHRva2VuS2V5OiBcIlwiLFxyXG4gICAgICAgIHJlc3VtZWlkOicnXHJcbiAgICB9XHJcblxyXG4gICAgb25Mb2FkKG9wdGlvbnMpIHtcclxuICAgICAgICB0aGlzLmVkdWNhdGlvbmlkID0gb3B0aW9ucy5lZHVjYXRpb25pZDtcclxuICAgICAgICB0aGlzLnJlc3VtZWlkID0gb3B0aW9ucy5yZXN1bWVpZDtcclxuICAgICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgICAgIGNvbnN0IHRoYXQgPSB0aGlzO1xyXG4gICAgICAgIC8vIOiOt+WPlueZu+W9leS/oeaBr1xyXG4gICAgICAgIHd4LmdldFN0b3JhZ2Uoe1xyXG4gICAgICAgICAgICBrZXk6ICdsb2dpbkRhdGEnLFxyXG4gICAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAgICAgICAgIHRoYXQudG9rZW4gPSByZXMuZGF0YS50b2tlbjtcclxuICAgICAgICAgICAgICAgIHRoYXQudG9rZW5LZXkgPSByZXMuZGF0YS50b2tlbktleTtcclxuICAgICAgICAgICAgICAgIHRoYXQuJGFwcGx5KCk7XHJcbiAgICAgICAgICAgICAgICAvL+iOt+WPluaxguiBjOaEj+WQkVxyXG4gICAgICAgICAgICAgICAgaWYob3B0aW9ucy5yZXN1bWVpZD09Jycpe1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoYXQuZ2V0Sm9iSW5mbyh0aGF0LnRva2VuLHRoYXQudG9rZW5LZXksdGhhdC5yZXN1bWVpZCkudGhlbihqc29uID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoanNvbi5kYXRhLnJldHVybkNvZGUgPT0gXCJBQUFBQUFBXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGpvYkV4cGVyID0gSlNPTi5wYXJzZShqc29uLmRhdGEuZGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXN1bHRBcnIgPSBqb2JFeHBlci5maW5kKGl0ZW0gPT4gaXRlbS5lZHVjYXRpb25pZCA9PSBvcHRpb25zLmVkdWNhdGlvbmlkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGF0LnNjaG9vbCA9IHJlc3VsdEFyci5zY2hvb2w7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoYXQuc3BlY2lhbHR5aWQgPSByZXN1bHRBcnIuc3BlY2lhbHR5aWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoYXQuc3RhcnR0aW1lID0gcmVzdWx0QXJyLnN0YXJ0dGltZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC5lbmR0aW1lID0gcmVzdWx0QXJyLmVuZHRpbWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoYXQuYV9lZHVjYXRpb25iZyA9IHJlc3VsdEFyci5lZHVjYXRpb25iZztcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXAuZXJyb3IoanNvbi5yZXR1cm5Nc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICAvLyDojrflj5bmlbDmja7lrZflhbjmlbDmja5cclxuICAgICAgICB0aGlzLmdldERpY3QoXCJESUNUX0pPQl9FRFVcIikudGhlbihqc29uID0+IHtcclxuICAgICAgICAgICAgaWYgKGpzb24uZGF0YS5yZXR1cm5Db2RlID09IFwiQUFBQUFBQVwiKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgYXJyID0gW11cclxuICAgICAgICAgICAgICAgIGpzb24uZGF0YS5kYXRhLmZvckVhY2goKGl0ZW0saW5kZXgpPT57XHJcbiAgICAgICAgICAgICAgICAgICAgYXJyLnB1c2goaXRlbS5sYWJlbClcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICB0aGF0LmVkdWNhdGlvbmJnID0gYXJyO1xyXG4gICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRpcC5lcnJvcihqc29uLnJldHVybk1zZyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgLy8g5o+Q5Lqk6KGo5Y2VLS3ln7rmnKzkv6Hmga/nvJbovpHmlrDlop5cclxuICAgICAgICBmb3JtU3VibWl0OiBmdW5jdGlvbihlKSB7XHJcbiAgICAgICAgICAgIHd4LnNob3dMb2FkaW5nKHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiAn5Yqg6L295LitJyxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgaWYodGhpcy5lZHVjYXRpb25pZCAhPSBcInVuZGVmaW5lZFwiKXtcclxuICAgICAgICAgICAgICAgIGUuZGV0YWlsLnZhbHVlLmVkdWNhdGlvbmlkID0gdGhpcy5lZHVjYXRpb25pZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB2YXIgb2JqMiA9IHtcclxuICAgICAgICAgICAgICAgIFwidG9rZW5cIjogdGhpcy50b2tlbixcclxuICAgICAgICAgICAgICAgIFwidG9rZW5LZXlcIjogdGhpcy50b2tlbktleSxcclxuICAgICAgICAgICAgICAgIFwicmVzdW1laWRcIjogdGhpcy5yZXN1bWVpZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmKCFvYmoyLnJlc3VtZWlkKXtcclxuICAgICAgICAgICAgICAgIGRlbGV0ZSBvYmoyWydyZXN1bWVpZCddXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY29uc3QgdGhhdCA9IHRoaXM7XHJcbiAgICAgICAgICAgIHRoaXMuY2hhbmdlQmFzZUluZm8oZS5kZXRhaWwudmFsdWUsb2JqMikudGhlbihkYXRhPT57XHJcbiAgICAgICAgICAgICAgICBpZihkYXRhLmRhdGEgJiYgZGF0YS5kYXRhLnJldHVybkNvZGUgPT0gXCJBQUFBQUFBXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICB3eC5yZWRpcmVjdFRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBgcmVzdW1lP3Jlc3VtZWlkPSR7dGhhdC5yZXN1bWVpZH1gXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB3eC5oaWRlTG9hZGluZygpXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfSxcclxuICAgICAgICBiaW5kRGF0ZUNoYW5nZTE6IGZ1bmN0aW9uKGUpIHtcclxuICAgICAgICAgICAgdGhpcy5zdGFydHRpbWUgPSBlLmRldGFpbC52YWx1ZTtcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJpbmREYXRlQ2hhbmdlMjogZnVuY3Rpb24oZSkge1xyXG4gICAgICAgICAgICB0aGlzLmVuZHRpbWUgPSBlLmRldGFpbC52YWx1ZTtcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJpbmRQaWNrZXJDaGFuZ2U6IGZ1bmN0aW9uKGUpIHtcclxuICAgICAgICAgICAgdGhpcy5lZHVjYXRpb25iZ3N0YXR1cyA9IGZhbHNlIDtcclxuICAgICAgICAgICAgdGhpcy5pbmRleCA9IGUuZGV0YWlsLnZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgICAgIH0sXHJcbiAgICB9XHJcblxyXG4gICAgLy/ojrflj5bmlZnogrLnu4/ljoZcclxuICAgIGFzeW5jIGdldEpvYkluZm8odG9rZW4sdG9rZW5LZXkscmVzdW1laWQpIHtcclxuICAgICAgICBjb25zdCBqc29uID0gYXdhaXQgYXBpLmdldFJlc3VtZUluZm8oe1xyXG4gICAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgICAgICAgICBoZWFkOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgXCJ0cmFuc2NvZGVcIjogXCJNMDAwNlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcImhcIlxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgICAgICBcInRva2VuXCI6IHRva2VuLFxyXG4gICAgICAgICAgICAgICAgICAgIFwidG9rZW5LZXlcIjogdG9rZW5LZXksXHJcbiAgICAgICAgICAgICAgICAgICAgXCJyZXN1bWVpZFwiOiByZXN1bWVpZFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICByZXR1cm4ganNvbjtcclxuICAgIH1cclxuXHJcbiAgICAvL+iOt+WPluaVsOaNruWtl+WFuFxyXG4gICAgYXN5bmMgZ2V0RGljdChjb2RlKSB7XHJcbiAgICAgICAgY29uc3QganNvbiA9IGF3YWl0IGFwaS5nZXREaWN0RGF0YSh7XHJcbiAgICAgICAgcXVlcnk6IHtcclxuICAgICAgICAgICAgICAgIGhlYWQ6IHtcclxuICAgICAgICAgICAgICAgICAgICBcInRyYW5zY29kZVwiOiBcIkRDMDAxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiaFwiXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgICAgIFwiZ3JvdXBjb2RlXCI6IGNvZGUsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJzZWxBbGxcIjogXCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgcmV0dXJuIGpzb247XHJcbiAgICB9XHJcblxyXG4gICAgLy/kv67mlLnooajljZXmlbDmja5cclxuICAgIGFzeW5jIGNoYW5nZUJhc2VJbmZvKG9iaixvYmoyKSB7XHJcbiAgICAgICAgbGV0IGRhdGEgPSBvYmoyXHJcbiAgICAgICAgbGV0IHJlc3VsdE9iaiA9IE9iamVjdC5hc3NpZ24oZGF0YSwgb2JqKTtcclxuICAgICAgICBjb25zdCBqc29uID0gYXdhaXQgYXBpLmdldFJlc3VtZUluZm8oe1xyXG4gICAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgICAgICAgICBoZWFkOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgXCJ0cmFuc2NvZGVcIjogXCJNMDAxNlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcImhcIlxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGRhdGE6IHJlc3VsdE9ialxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICByZXR1cm4ganNvbjtcclxuICAgIH1cclxuICB9XHJcbiJdfQ==