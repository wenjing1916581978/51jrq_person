'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _api = require('./../../api/api.js');

var _api2 = _interopRequireDefault(_api);

var _tip = require('./../../utils/tip.js');

var _tip2 = _interopRequireDefault(_tip);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BaseInfo = function (_wepy$page) {
    _inherits(BaseInfo, _wepy$page);

    function BaseInfo() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, BaseInfo);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = BaseInfo.__proto__ || Object.getPrototypeOf(BaseInfo)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: '证书'
        }, _this.data = {
            certname: '',
            gaintime: '',
            certid: '',
            token: "",
            tokenKey: "",
            resumeid: ''
        }, _this.methods = {
            // 提交表单--基本信息编辑新增
            formSubmit: function formSubmit(e) {
                wx.showLoading({
                    title: '加载中'
                });
                if (this.certid != "undefined") {
                    e.detail.value.certid = this.certid;
                }
                var obj2 = {
                    "token": this.token,
                    "tokenKey": this.tokenKey,
                    "resumeid": this.resumeid
                };
                if (!obj2.resumeid) {
                    delete obj2['resumeid'];
                }
                var that = this;
                this.changeBaseInfo(e.detail.value, obj2).then(function (data) {
                    if (data.data && data.data.returnCode == "AAAAAAA") {
                        wx.redirectTo({
                            url: 'resume?resumeid=' + that.resumeid
                        });
                    } else {
                        console.log(data);
                    }
                    wx.hideLoading();
                });
            },
            bindDateChange1: function bindDateChange1(e) {
                this.starttime = e.detail.value;
                this.$apply();
            },
            bindDateChange2: function bindDateChange2(e) {
                this.gaintime = e.detail.value;
                this.$apply();
            }

            //获取证书
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(BaseInfo, [{
        key: 'onLoad',
        value: function onLoad(options) {
            this.certid = options.certid;
            this.resumeid = options.resumeid;
            this.$apply();
            var that = this;
            // 获取登录信息
            wx.getStorage({
                key: 'loginData',
                success: function success(res) {
                    that.token = res.data.token;
                    that.tokenKey = res.data.tokenKey;
                    that.$apply();
                    if (options.resumeid == '') {
                        return false;
                    }
                    //获取求职意向
                    that.getJobInfo(that.token, that.tokenKey, that.resumeid).then(function (json) {
                        if (json.data.returnCode == "AAAAAAA") {
                            var jobExper = JSON.parse(json.data.data);
                            var resultArr = jobExper.find(function (item) {
                                return item.certid == options.certid;
                            });
                            that.certname = resultArr.certname;
                            that.gaintime = resultArr.gaintime;
                            that.$apply();
                        } else {
                            _tip2.default.error(json.returnMsg);
                        }
                    });
                }
            });
        }
    }, {
        key: 'getJobInfo',
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(token, tokenKey, resumeid) {
                var json;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _api2.default.getResumeInfo({
                                    query: {
                                        head: {
                                            "transcode": "M0010",
                                            "type": "h"
                                        },
                                        data: {
                                            "token": token,
                                            "tokenKey": tokenKey,
                                            "resumeid": resumeid
                                        }
                                    }
                                });

                            case 2:
                                json = _context.sent;
                                return _context.abrupt('return', json);

                            case 4:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function getJobInfo(_x, _x2, _x3) {
                return _ref2.apply(this, arguments);
            }

            return getJobInfo;
        }()

        //修改表单数据

    }, {
        key: 'changeBaseInfo',
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(obj, obj2) {
                var data, resultObj, json;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                data = obj2;
                                resultObj = Object.assign(data, obj);
                                _context2.next = 4;
                                return _api2.default.getResumeInfo({
                                    query: {
                                        head: {
                                            "transcode": "M0020",
                                            "type": "h"
                                        },
                                        data: resultObj
                                    }
                                });

                            case 4:
                                json = _context2.sent;
                                return _context2.abrupt('return', json);

                            case 6:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function changeBaseInfo(_x4, _x5) {
                return _ref3.apply(this, arguments);
            }

            return changeBaseInfo;
        }()
    }]);

    return BaseInfo;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(BaseInfo , 'pages/personal/certificate'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNlcnRpZmljYXRlLmpzIl0sIm5hbWVzIjpbIkJhc2VJbmZvIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJjZXJ0bmFtZSIsImdhaW50aW1lIiwiY2VydGlkIiwidG9rZW4iLCJ0b2tlbktleSIsInJlc3VtZWlkIiwibWV0aG9kcyIsImZvcm1TdWJtaXQiLCJlIiwid3giLCJzaG93TG9hZGluZyIsInRpdGxlIiwiZGV0YWlsIiwidmFsdWUiLCJvYmoyIiwidGhhdCIsImNoYW5nZUJhc2VJbmZvIiwidGhlbiIsInJldHVybkNvZGUiLCJyZWRpcmVjdFRvIiwidXJsIiwiY29uc29sZSIsImxvZyIsImhpZGVMb2FkaW5nIiwiYmluZERhdGVDaGFuZ2UxIiwic3RhcnR0aW1lIiwiJGFwcGx5IiwiYmluZERhdGVDaGFuZ2UyIiwib3B0aW9ucyIsImdldFN0b3JhZ2UiLCJrZXkiLCJzdWNjZXNzIiwicmVzIiwiZ2V0Sm9iSW5mbyIsImpzb24iLCJqb2JFeHBlciIsIkpTT04iLCJwYXJzZSIsInJlc3VsdEFyciIsImZpbmQiLCJpdGVtIiwiZXJyb3IiLCJyZXR1cm5Nc2ciLCJnZXRSZXN1bWVJbmZvIiwicXVlcnkiLCJoZWFkIiwib2JqIiwicmVzdWx0T2JqIiwiT2JqZWN0IiwiYXNzaWduIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUVxQkEsUTs7Ozs7Ozs7Ozs7Ozs7OExBRW5CQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFJVEMsSSxHQUFPO0FBQ0hDLHNCQUFTLEVBRE47QUFFSEMsc0JBQVMsRUFGTjtBQUdIQyxvQkFBTyxFQUhKO0FBSUhDLG1CQUFPLEVBSko7QUFLSEMsc0JBQVUsRUFMUDtBQU1IQyxzQkFBUztBQU5OLFMsUUEwQ1BDLE8sR0FBVTtBQUNOO0FBQ0FDLHdCQUFZLG9CQUFTQyxDQUFULEVBQVk7QUFDcEJDLG1CQUFHQyxXQUFILENBQWU7QUFDWEMsMkJBQU87QUFESSxpQkFBZjtBQUdBLG9CQUFHLEtBQUtULE1BQUwsSUFBZSxXQUFsQixFQUE4QjtBQUMxQk0sc0JBQUVJLE1BQUYsQ0FBU0MsS0FBVCxDQUFlWCxNQUFmLEdBQXdCLEtBQUtBLE1BQTdCO0FBQ0g7QUFDRCxvQkFBSVksT0FBTztBQUNQLDZCQUFTLEtBQUtYLEtBRFA7QUFFUCxnQ0FBWSxLQUFLQyxRQUZWO0FBR1AsZ0NBQVksS0FBS0M7QUFIVixpQkFBWDtBQUtBLG9CQUFHLENBQUNTLEtBQUtULFFBQVQsRUFBa0I7QUFDZCwyQkFBT1MsS0FBSyxVQUFMLENBQVA7QUFDSDtBQUNELG9CQUFNQyxPQUFPLElBQWI7QUFDQSxxQkFBS0MsY0FBTCxDQUFvQlIsRUFBRUksTUFBRixDQUFTQyxLQUE3QixFQUFvQ0MsSUFBcEMsRUFBMENHLElBQTFDLENBQStDLGdCQUFNO0FBQ2pELHdCQUFHbEIsS0FBS0EsSUFBTCxJQUFhQSxLQUFLQSxJQUFMLENBQVVtQixVQUFWLElBQXdCLFNBQXhDLEVBQW1EO0FBQy9DVCwyQkFBR1UsVUFBSCxDQUFjO0FBQ1ZDLHNEQUF3QkwsS0FBS1Y7QUFEbkIseUJBQWQ7QUFHSCxxQkFKRCxNQUlLO0FBQ0RnQixnQ0FBUUMsR0FBUixDQUFZdkIsSUFBWjtBQUNIO0FBQ0RVLHVCQUFHYyxXQUFIO0FBQ0gsaUJBVEQ7QUFVSCxhQTVCSztBQTZCTkMsNkJBQWlCLHlCQUFTaEIsQ0FBVCxFQUFZO0FBQ3pCLHFCQUFLaUIsU0FBTCxHQUFpQmpCLEVBQUVJLE1BQUYsQ0FBU0MsS0FBMUI7QUFDQSxxQkFBS2EsTUFBTDtBQUNILGFBaENLO0FBaUNOQyw2QkFBaUIseUJBQVNuQixDQUFULEVBQVk7QUFDekIscUJBQUtQLFFBQUwsR0FBZ0JPLEVBQUVJLE1BQUYsQ0FBU0MsS0FBekI7QUFDQSxxQkFBS2EsTUFBTDtBQUNIOztBQUdMO0FBdkNVLFM7Ozs7OytCQWpDSEUsTyxFQUFTO0FBQ1osaUJBQUsxQixNQUFMLEdBQWMwQixRQUFRMUIsTUFBdEI7QUFDQSxpQkFBS0csUUFBTCxHQUFnQnVCLFFBQVF2QixRQUF4QjtBQUNBLGlCQUFLcUIsTUFBTDtBQUNBLGdCQUFNWCxPQUFPLElBQWI7QUFDQTtBQUNBTixlQUFHb0IsVUFBSCxDQUFjO0FBQ1ZDLHFCQUFLLFdBREs7QUFFVkMseUJBQVMsaUJBQVNDLEdBQVQsRUFBYztBQUNuQmpCLHlCQUFLWixLQUFMLEdBQWE2QixJQUFJakMsSUFBSixDQUFTSSxLQUF0QjtBQUNBWSx5QkFBS1gsUUFBTCxHQUFnQjRCLElBQUlqQyxJQUFKLENBQVNLLFFBQXpCO0FBQ0FXLHlCQUFLVyxNQUFMO0FBQ0Esd0JBQUdFLFFBQVF2QixRQUFSLElBQWtCLEVBQXJCLEVBQXdCO0FBQ3RCLCtCQUFPLEtBQVA7QUFDRDtBQUNEO0FBQ0FVLHlCQUFLa0IsVUFBTCxDQUFnQmxCLEtBQUtaLEtBQXJCLEVBQTJCWSxLQUFLWCxRQUFoQyxFQUF5Q1csS0FBS1YsUUFBOUMsRUFBd0RZLElBQXhELENBQTZELGdCQUFRO0FBQ2pFLDRCQUFJaUIsS0FBS25DLElBQUwsQ0FBVW1CLFVBQVYsSUFBd0IsU0FBNUIsRUFBdUM7QUFDbkMsZ0NBQUlpQixXQUFXQyxLQUFLQyxLQUFMLENBQVdILEtBQUtuQyxJQUFMLENBQVVBLElBQXJCLENBQWY7QUFDQSxnQ0FBSXVDLFlBQVlILFNBQVNJLElBQVQsQ0FBYztBQUFBLHVDQUFRQyxLQUFLdEMsTUFBTCxJQUFlMEIsUUFBUTFCLE1BQS9CO0FBQUEsNkJBQWQsQ0FBaEI7QUFDQWEsaUNBQUtmLFFBQUwsR0FBZ0JzQyxVQUFVdEMsUUFBMUI7QUFDQWUsaUNBQUtkLFFBQUwsR0FBZ0JxQyxVQUFVckMsUUFBMUI7QUFDQWMsaUNBQUtXLE1BQUw7QUFDSCx5QkFORCxNQU1PO0FBQ0gsMENBQUllLEtBQUosQ0FBVVAsS0FBS1EsU0FBZjtBQUNIO0FBQ0oscUJBVkQ7QUFXSDtBQXJCUyxhQUFkO0FBeUJIOzs7O2lHQTBDZ0J2QyxLLEVBQU1DLFEsRUFBU0MsUTs7Ozs7Ozt1Q0FDVCxjQUFJc0MsYUFBSixDQUFrQjtBQUNyQ0MsMkNBQU87QUFDQ0MsOENBQU07QUFDRix5REFBYSxPQURYO0FBRUYsb0RBQVE7QUFGTix5Q0FEUDtBQUtDOUMsOENBQU07QUFDRixxREFBU0ksS0FEUDtBQUVGLHdEQUFZQyxRQUZWO0FBR0Ysd0RBQVlDO0FBSFY7QUFMUDtBQUQ4QixpQ0FBbEIsQzs7O0FBQWI2QixvQztpRUFhQ0EsSTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFHWDs7Ozs7a0dBQ3FCWSxHLEVBQUloQyxJOzs7Ozs7QUFDakJmLG9DLEdBQU9lLEk7QUFDUGlDLHlDLEdBQVlDLE9BQU9DLE1BQVAsQ0FBY2xELElBQWQsRUFBb0IrQyxHQUFwQixDOzt1Q0FDRyxjQUFJSCxhQUFKLENBQWtCO0FBQ3JDQywyQ0FBTztBQUNDQyw4Q0FBTTtBQUNGLHlEQUFhLE9BRFg7QUFFRixvREFBUTtBQUZOLHlDQURQO0FBS0M5Qyw4Q0FBTWdEO0FBTFA7QUFEOEIsaUNBQWxCLEM7OztBQUFiYixvQztrRUFTQ0EsSTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXRIeUIsZUFBS2dCLEk7O2tCQUF0QnRELFEiLCJmaWxlIjoiY2VydGlmaWNhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tICd3ZXB5J1xyXG4gIGltcG9ydCBhcGkgZnJvbSAnLi4vLi4vYXBpL2FwaSc7XHJcbiAgaW1wb3J0IHRpcCBmcm9tICcuLi8uLi91dGlscy90aXAnO1xyXG5cclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBCYXNlSW5mbyBleHRlbmRzIHdlcHkucGFnZSB7XHJcblxyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6ICfor4HkuaYnLFxyXG4gICAgfVxyXG5cclxuICAgIGRhdGEgPSB7XHJcbiAgICAgICAgY2VydG5hbWU6JycsXHJcbiAgICAgICAgZ2FpbnRpbWU6JycsXHJcbiAgICAgICAgY2VydGlkOicnLFxyXG4gICAgICAgIHRva2VuOiBcIlwiLFxyXG4gICAgICAgIHRva2VuS2V5OiBcIlwiLFxyXG4gICAgICAgIHJlc3VtZWlkOicnXHJcbiAgICB9XHJcblxyXG4gICAgb25Mb2FkKG9wdGlvbnMpIHtcclxuICAgICAgICB0aGlzLmNlcnRpZCA9IG9wdGlvbnMuY2VydGlkO1xyXG4gICAgICAgIHRoaXMucmVzdW1laWQgPSBvcHRpb25zLnJlc3VtZWlkO1xyXG4gICAgICAgIHRoaXMuJGFwcGx5KCk7XHJcbiAgICAgICAgY29uc3QgdGhhdCA9IHRoaXM7XHJcbiAgICAgICAgLy8g6I635Y+W55m75b2V5L+h5oGvXHJcbiAgICAgICAgd3guZ2V0U3RvcmFnZSh7XHJcbiAgICAgICAgICAgIGtleTogJ2xvZ2luRGF0YScsXHJcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgICAgICAgICAgdGhhdC50b2tlbiA9IHJlcy5kYXRhLnRva2VuO1xyXG4gICAgICAgICAgICAgICAgdGhhdC50b2tlbktleSA9IHJlcy5kYXRhLnRva2VuS2V5O1xyXG4gICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgIGlmKG9wdGlvbnMucmVzdW1laWQ9PScnKXtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvL+iOt+WPluaxguiBjOaEj+WQkVxyXG4gICAgICAgICAgICAgICAgdGhhdC5nZXRKb2JJbmZvKHRoYXQudG9rZW4sdGhhdC50b2tlbktleSx0aGF0LnJlc3VtZWlkKS50aGVuKGpzb24gPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChqc29uLmRhdGEucmV0dXJuQ29kZSA9PSBcIkFBQUFBQUFcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgam9iRXhwZXIgPSBKU09OLnBhcnNlKGpzb24uZGF0YS5kYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3VsdEFyciA9IGpvYkV4cGVyLmZpbmQoaXRlbSA9PiBpdGVtLmNlcnRpZCA9PSBvcHRpb25zLmNlcnRpZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC5jZXJ0bmFtZSA9IHJlc3VsdEFyci5jZXJ0bmFtZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC5nYWludGltZSA9IHJlc3VsdEFyci5nYWludGltZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXAuZXJyb3IoanNvbi5yZXR1cm5Nc2cpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG5cclxuXHJcbiAgICB9XHJcblxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAvLyDmj5DkuqTooajljZUtLeWfuuacrOS/oeaBr+e8lui+keaWsOWinlxyXG4gICAgICAgIGZvcm1TdWJtaXQ6IGZ1bmN0aW9uKGUpIHtcclxuICAgICAgICAgICAgd3guc2hvd0xvYWRpbmcoe1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6ICfliqDovb3kuK0nLFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICBpZih0aGlzLmNlcnRpZCAhPSBcInVuZGVmaW5lZFwiKXtcclxuICAgICAgICAgICAgICAgIGUuZGV0YWlsLnZhbHVlLmNlcnRpZCA9IHRoaXMuY2VydGlkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHZhciBvYmoyID0ge1xyXG4gICAgICAgICAgICAgICAgXCJ0b2tlblwiOiB0aGlzLnRva2VuLFxyXG4gICAgICAgICAgICAgICAgXCJ0b2tlbktleVwiOiB0aGlzLnRva2VuS2V5LFxyXG4gICAgICAgICAgICAgICAgXCJyZXN1bWVpZFwiOiB0aGlzLnJlc3VtZWlkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYoIW9iajIucmVzdW1laWQpe1xyXG4gICAgICAgICAgICAgICAgZGVsZXRlIG9iajJbJ3Jlc3VtZWlkJ11cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCB0aGF0ID0gdGhpcztcclxuICAgICAgICAgICAgdGhpcy5jaGFuZ2VCYXNlSW5mbyhlLmRldGFpbC52YWx1ZSwgb2JqMikudGhlbihkYXRhPT57XHJcbiAgICAgICAgICAgICAgICBpZihkYXRhLmRhdGEgJiYgZGF0YS5kYXRhLnJldHVybkNvZGUgPT0gXCJBQUFBQUFBXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICB3eC5yZWRpcmVjdFRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBgcmVzdW1lP3Jlc3VtZWlkPSR7dGhhdC5yZXN1bWVpZH1gXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB3eC5oaWRlTG9hZGluZygpXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfSxcclxuICAgICAgICBiaW5kRGF0ZUNoYW5nZTE6IGZ1bmN0aW9uKGUpIHtcclxuICAgICAgICAgICAgdGhpcy5zdGFydHRpbWUgPSBlLmRldGFpbC52YWx1ZTtcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJpbmREYXRlQ2hhbmdlMjogZnVuY3Rpb24oZSkge1xyXG4gICAgICAgICAgICB0aGlzLmdhaW50aW1lID0gZS5kZXRhaWwudmFsdWU7XHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KCk7XHJcbiAgICAgICAgfSxcclxuICAgIH1cclxuXHJcbiAgICAvL+iOt+WPluivgeS5plxyXG4gICAgYXN5bmMgZ2V0Sm9iSW5mbyh0b2tlbix0b2tlbktleSxyZXN1bWVpZCkge1xyXG4gICAgICAgIGNvbnN0IGpzb24gPSBhd2FpdCBhcGkuZ2V0UmVzdW1lSW5mbyh7XHJcbiAgICAgICAgcXVlcnk6IHtcclxuICAgICAgICAgICAgICAgIGhlYWQ6IHtcclxuICAgICAgICAgICAgICAgICAgICBcInRyYW5zY29kZVwiOiBcIk0wMDEwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiaFwiXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgICAgIFwidG9rZW5cIjogdG9rZW4sXHJcbiAgICAgICAgICAgICAgICAgICAgXCJ0b2tlbktleVwiOiB0b2tlbktleSxcclxuICAgICAgICAgICAgICAgICAgICBcInJlc3VtZWlkXCI6IHJlc3VtZWlkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgIHJldHVybiBqc29uO1xyXG4gICAgfVxyXG5cclxuICAgIC8v5L+u5pS56KGo5Y2V5pWw5o2uXHJcbiAgICBhc3luYyBjaGFuZ2VCYXNlSW5mbyhvYmosb2JqMikge1xyXG4gICAgICAgIGxldCBkYXRhID0gb2JqMlxyXG4gICAgICAgIGxldCByZXN1bHRPYmogPSBPYmplY3QuYXNzaWduKGRhdGEsIG9iaik7XHJcbiAgICAgICAgY29uc3QganNvbiA9IGF3YWl0IGFwaS5nZXRSZXN1bWVJbmZvKHtcclxuICAgICAgICBxdWVyeToge1xyXG4gICAgICAgICAgICAgICAgaGVhZDoge1xyXG4gICAgICAgICAgICAgICAgICAgIFwidHJhbnNjb2RlXCI6IFwiTTAwMjBcIixcclxuICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJoXCJcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBkYXRhOiByZXN1bHRPYmpcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgcmV0dXJuIGpzb247XHJcbiAgICB9XHJcbiAgfVxyXG4iXX0=