'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _api = require('./../../api/api.js');

var _api2 = _interopRequireDefault(_api);

var _tip = require('./../../utils/tip.js');

var _tip2 = _interopRequireDefault(_tip);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var resumePage = function (_wepy$page) {
  _inherits(resumePage, _wepy$page);

  function resumePage() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, resumePage);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = resumePage.__proto__ || Object.getPrototypeOf(resumePage)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: '我的简历'
    }, _this.data = {
      baseInfo: {}, // 基本信息
      jobApply: {}, // 求职意向
      workExper: {}, // 工作经历
      eduExper: {}, // 教育经历
      projectExper: {}, // 项目经验
      certificate: {}, // 证书
      sex: true,
      token: '',
      tokenKey: '',
      headimg: '',
      resumeid: '',
      operateShow: false,
      sexStatus: false,
      tempPortraitFilePath: '',
      headimgStatus: false
    }, _this.methods = {

      // 基本信息编辑新增
      goBaseInfo: function goBaseInfo(resumeid) {
        wx.navigateTo({
          url: 'base_info?resumeid=' + resumeid
        });
      },


      // 求职意向
      goJobWant: function goJobWant(resumeid) {
        wx.navigateTo({
          url: 'job_want?resumeid=' + resumeid
        });
      },


      // 工作经历
      goWorkExper: function goWorkExper(workid, resumeid) {
        wx.navigateTo({
          url: 'work_exper?workid=' + workid + '&resumeid=' + resumeid
        });
      },


      // 教育经历
      goEduExper: function goEduExper(educationid, resumeid) {
        wx.navigateTo({
          url: 'edu_exper?educationid=' + educationid + '&resumeid=' + resumeid
        });
      },


      // 项目经验
      goProjectExper: function goProjectExper(projectid, resumeid) {
        wx.navigateTo({
          url: 'project_exper?projectid=' + projectid + '&resumeid=' + resumeid
        });
      },


      // 证书
      goCert: function goCert(certid, resumeid) {
        wx.navigateTo({
          url: 'certificate?certid=' + certid + '&resumeid=' + resumeid
        });
      }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(resumePage, [{
    key: 'onLoad',
    value: function onLoad(options) {
      this.resumeid = options.resumeid;
      // console.log(this.resumeid)
      if (options.look == "just") {
        this.operateShow = true;
      } else {
        this.operateShow = false;
      }
      this.$apply();
      var that = this;
      // 获取登录信息
      wx.getStorage({
        key: 'loginData',
        success: function success(res) {
          that.token = res.data.token;
          that.tokenKey = res.data.tokenKey;
          that.headimg = res.data.data.headimg;
          that.getPimg();
          that.$apply();
          // 获取简历信息
          if (options.resumeid === undefined) {
            return false;
          }
          var arr = ["M0003", "M0004", "M0005", "M0006", "M0008", "M0010"];
          arr.forEach(function (item, index) {
            switch (item) {
              case "M0003":
                // 基本信息
                that.getJobInfo(item, that.resumeid, that.token, that.tokenKey).then(function (json) {
                  if (json.data.returnCode == "AAAAAAA") {
                    that.baseInfo = JSON.parse(json.data.data);
                    that.sex = that.baseInfo.sex == "男";
                    if (!that.baseInfo.sex) {
                      that.sexStatus = true;
                    } else {
                      that.sexStatus = false;
                    }
                    that.$apply();
                  } else {
                    that.sexStatus = true;
                    that.$apply();
                    _tip2.default.error(json.returnMsg);
                  }
                });
                break;
              case "M0004":
                // 求职意向
                that.getJobInfo(item, that.resumeid, that.token, that.tokenKey).then(function (json) {
                  if (json.data.returnCode == "AAAAAAA") {
                    that.jobApply = JSON.parse(json.data.data);
                    that.$apply();
                  } else {
                    _tip2.default.error(json.returnMsg);
                  }
                });
                break;
              case "M0005":
                // 工作经历
                that.getJobInfo(item, that.resumeid, that.token, that.tokenKey).then(function (json) {
                  if (json.data.returnCode == "AAAAAAA") {
                    that.workExper = JSON.parse(json.data.data);
                    that.$apply();
                  } else {
                    _tip2.default.error(json.returnMsg);
                  }
                });
                break;
              case "M0006":
                // 教育经历
                that.getJobInfo(item, that.resumeid, that.token, that.tokenKey).then(function (json) {
                  if (json.data.returnCode == "AAAAAAA") {
                    that.eduExper = JSON.parse(json.data.data);
                    that.$apply();
                  } else {
                    _tip2.default.error(json.returnMsg);
                  }
                });
                break;
              case "M0008":
                // 项目经验
                that.getJobInfo(item, that.resumeid, that.token, that.tokenKey).then(function (json) {
                  if (json.data.returnCode == "AAAAAAA") {
                    that.projectExper = JSON.parse(json.data.data);
                    that.$apply();
                  } else {
                    _tip2.default.error(json.returnMsg);
                  }
                });
                break;
              case "M0010":
                // 证书
                that.getJobInfo(item, that.resumeid, that.token, that.tokenKey).then(function (json) {
                  if (json.data.returnCode == "AAAAAAA") {
                    that.certificate = JSON.parse(json.data.data);
                    that.$apply();
                  } else {
                    _tip2.default.error(json.returnMsg);
                  }
                });
                break;
            }
          });
        },
        fail: function fail(json) {
          _tip2.default.error(json.data.returnMsg);
        }
      });
    }
  }, {
    key: 'getJobInfo',


    //获取公司详情数据
    value: function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(code, resumeid, token, tokenKey) {
        var json;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _api2.default.getResumeInfo({
                  query: {
                    head: {
                      "transcode": code,
                      "type": "h"
                    },
                    data: {
                      "token": token,
                      "tokenKey": tokenKey,
                      "resumeid": resumeid
                    }
                  }
                });

              case 2:
                json = _context.sent;
                return _context.abrupt('return', json);

              case 4:
              case 'end':
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function getJobInfo(_x, _x2, _x3, _x4) {
        return _ref2.apply(this, arguments);
      }

      return getJobInfo;
    }()

    //修改头像

  }, {
    key: 'changPic',
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(token, tokenKey, imgsrc) {
        var json;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return _api2.default.getResumeInfo({
                  query: {
                    head: {
                      "type": "i",
                      "transcode": "P0038"
                    },
                    data: {
                      "imgsrc": imgsrc,
                      "imgtype": "png",
                      "tokenKey": tokenKey,
                      "token": token
                    }
                  }
                });

              case 2:
                json = _context2.sent;
                return _context2.abrupt('return', json);

              case 4:
              case 'end':
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function changPic(_x5, _x6, _x7) {
        return _ref3.apply(this, arguments);
      }

      return changPic;
    }()
    //获取个人信息

  }, {
    key: 'getPimg',
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var that, json;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                that = this;
                _context3.next = 3;
                return _api2.default.getPimg({
                  query: {
                    head: {
                      "transcode": "P0040",
                      "type": "h"
                    },
                    data: {
                      "tokenKey": that.tokenKey,
                      "token": that.token
                    }
                  }
                });

              case 3:
                json = _context3.sent;

                if (json.data.returnCode == 'AAAAAAA') {
                  if (json.data.data.headimg) {
                    that.headimgStatus = true;
                  } else {
                    that.headimgStatus = false;
                  }
                  that.tempPortraitFilePath = json.data.data.headimg;
                  that.$apply();
                } else {
                  _tip2.default.error(json.data.returnMsg);
                }

              case 5:
              case 'end':
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function getPimg() {
        return _ref4.apply(this, arguments);
      }

      return getPimg;
    }()
  }]);

  return resumePage;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(resumePage , 'pages/personal/resume'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlc3VtZS5qcyJdLCJuYW1lcyI6WyJyZXN1bWVQYWdlIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJiYXNlSW5mbyIsImpvYkFwcGx5Iiwid29ya0V4cGVyIiwiZWR1RXhwZXIiLCJwcm9qZWN0RXhwZXIiLCJjZXJ0aWZpY2F0ZSIsInNleCIsInRva2VuIiwidG9rZW5LZXkiLCJoZWFkaW1nIiwicmVzdW1laWQiLCJvcGVyYXRlU2hvdyIsInNleFN0YXR1cyIsInRlbXBQb3J0cmFpdEZpbGVQYXRoIiwiaGVhZGltZ1N0YXR1cyIsIm1ldGhvZHMiLCJnb0Jhc2VJbmZvIiwid3giLCJuYXZpZ2F0ZVRvIiwidXJsIiwiZ29Kb2JXYW50IiwiZ29Xb3JrRXhwZXIiLCJ3b3JraWQiLCJnb0VkdUV4cGVyIiwiZWR1Y2F0aW9uaWQiLCJnb1Byb2plY3RFeHBlciIsInByb2plY3RpZCIsImdvQ2VydCIsImNlcnRpZCIsIm9wdGlvbnMiLCJsb29rIiwiJGFwcGx5IiwidGhhdCIsImdldFN0b3JhZ2UiLCJrZXkiLCJzdWNjZXNzIiwicmVzIiwiZ2V0UGltZyIsInVuZGVmaW5lZCIsImFyciIsImZvckVhY2giLCJpdGVtIiwiaW5kZXgiLCJnZXRKb2JJbmZvIiwidGhlbiIsImpzb24iLCJyZXR1cm5Db2RlIiwiSlNPTiIsInBhcnNlIiwiZXJyb3IiLCJyZXR1cm5Nc2ciLCJmYWlsIiwiY29kZSIsImdldFJlc3VtZUluZm8iLCJxdWVyeSIsImhlYWQiLCJpbWdzcmMiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBRXFCQSxVOzs7Ozs7Ozs7Ozs7Ozs4TEFFbkJDLE0sR0FBUztBQUNMQyw4QkFBd0I7QUFEbkIsSyxRQUlUQyxJLEdBQU87QUFDTEMsZ0JBQVUsRUFETCxFQUNjO0FBQ25CQyxnQkFBVSxFQUZMLEVBRWM7QUFDbkJDLGlCQUFXLEVBSE4sRUFHYztBQUNuQkMsZ0JBQVUsRUFKTCxFQUljO0FBQ25CQyxvQkFBYyxFQUxULEVBS2M7QUFDbkJDLG1CQUFhLEVBTlIsRUFNZTtBQUNwQkMsV0FBSyxJQVBBO0FBUUxDLGFBQU8sRUFSRjtBQVNMQyxnQkFBVSxFQVRMO0FBVUxDLGVBQVMsRUFWSjtBQVdMQyxnQkFBVSxFQVhMO0FBWUxDLG1CQUFhLEtBWlI7QUFhTEMsaUJBQVcsS0FiTjtBQWNMQyw0QkFBc0IsRUFkakI7QUFlTEMscUJBQWM7QUFmVCxLLFFBeUhQQyxPLEdBQVU7O0FBRUo7QUFDQUMsZ0JBSEksc0JBR1FOLFFBSFIsRUFHa0I7QUFDbEJPLFdBQUdDLFVBQUgsQ0FBYztBQUNWQyx1Q0FBMkJUO0FBRGpCLFNBQWQ7QUFHSCxPQVBHOzs7QUFTSjtBQUNBVSxlQVZJLHFCQVVPVixRQVZQLEVBVWlCO0FBQ2pCTyxXQUFHQyxVQUFILENBQWM7QUFDVkMsc0NBQTBCVDtBQURoQixTQUFkO0FBR0gsT0FkRzs7O0FBZ0JKO0FBQ0FXLGlCQWpCSSx1QkFpQlNDLE1BakJULEVBaUJpQlosUUFqQmpCLEVBaUIyQjtBQUMzQk8sV0FBR0MsVUFBSCxDQUFjO0FBQ1ZDLHNDQUEwQkcsTUFBMUIsa0JBQTZDWjtBQURuQyxTQUFkO0FBR0gsT0FyQkc7OztBQXVCSjtBQUNBYSxnQkF4Qkksc0JBd0JRQyxXQXhCUixFQXdCcUJkLFFBeEJyQixFQXdCK0I7QUFDL0JPLFdBQUdDLFVBQUgsQ0FBYztBQUNWQywwQ0FBOEJLLFdBQTlCLGtCQUFzRGQ7QUFENUMsU0FBZDtBQUdILE9BNUJHOzs7QUE4Qko7QUFDQWUsb0JBL0JJLDBCQStCWUMsU0EvQlosRUErQnVCaEIsUUEvQnZCLEVBK0JpQztBQUNqQ08sV0FBR0MsVUFBSCxDQUFjO0FBQ1ZDLDRDQUFnQ08sU0FBaEMsa0JBQXNEaEI7QUFENUMsU0FBZDtBQUdILE9BbkNHOzs7QUFxQ0o7QUFDQWlCLFlBdENJLGtCQXNDSUMsTUF0Q0osRUFzQ1lsQixRQXRDWixFQXNDc0I7QUFDdEJPLFdBQUdDLFVBQUgsQ0FBYztBQUNWQyx1Q0FBMkJTLE1BQTNCLGtCQUE4Q2xCO0FBRHBDLFNBQWQ7QUFHSDtBQTFDRyxLOzs7OzsyQkF2R0htQixPLEVBQVM7QUFDZCxXQUFLbkIsUUFBTCxHQUFnQm1CLFFBQVFuQixRQUF4QjtBQUNBO0FBQ0EsVUFBR21CLFFBQVFDLElBQVIsSUFBYyxNQUFqQixFQUF3QjtBQUN0QixhQUFLbkIsV0FBTCxHQUFtQixJQUFuQjtBQUNELE9BRkQsTUFFSztBQUNILGFBQUtBLFdBQUwsR0FBbUIsS0FBbkI7QUFDRDtBQUNELFdBQUtvQixNQUFMO0FBQ0EsVUFBTUMsT0FBTyxJQUFiO0FBQ0E7QUFDQWYsU0FBR2dCLFVBQUgsQ0FBYztBQUNWQyxhQUFLLFdBREs7QUFFVkMsaUJBQVMsaUJBQVNDLEdBQVQsRUFBYztBQUNuQkosZUFBS3pCLEtBQUwsR0FBYTZCLElBQUlyQyxJQUFKLENBQVNRLEtBQXRCO0FBQ0F5QixlQUFLeEIsUUFBTCxHQUFnQjRCLElBQUlyQyxJQUFKLENBQVNTLFFBQXpCO0FBQ0F3QixlQUFLdkIsT0FBTCxHQUFlMkIsSUFBSXJDLElBQUosQ0FBU0EsSUFBVCxDQUFjVSxPQUE3QjtBQUNBdUIsZUFBS0ssT0FBTDtBQUNBTCxlQUFLRCxNQUFMO0FBQ0E7QUFDQSxjQUFHRixRQUFRbkIsUUFBUixLQUFtQjRCLFNBQXRCLEVBQWdDO0FBQzlCLG1CQUFPLEtBQVA7QUFDRDtBQUNELGNBQU1DLE1BQU0sQ0FBQyxPQUFELEVBQVMsT0FBVCxFQUFpQixPQUFqQixFQUF5QixPQUF6QixFQUFpQyxPQUFqQyxFQUF5QyxPQUF6QyxDQUFaO0FBQ0FBLGNBQUlDLE9BQUosQ0FBWSxVQUFDQyxJQUFELEVBQU1DLEtBQU4sRUFBZ0I7QUFDMUIsb0JBQVFELElBQVI7QUFFQSxtQkFBSyxPQUFMO0FBQWE7QUFDWFQscUJBQUtXLFVBQUwsQ0FBZ0JGLElBQWhCLEVBQXNCVCxLQUFLdEIsUUFBM0IsRUFBcUNzQixLQUFLekIsS0FBMUMsRUFBaUR5QixLQUFLeEIsUUFBdEQsRUFBZ0VvQyxJQUFoRSxDQUFxRSxnQkFBUTtBQUMzRSxzQkFBSUMsS0FBSzlDLElBQUwsQ0FBVStDLFVBQVYsSUFBd0IsU0FBNUIsRUFBdUM7QUFDckNkLHlCQUFLaEMsUUFBTCxHQUFnQitDLEtBQUtDLEtBQUwsQ0FBV0gsS0FBSzlDLElBQUwsQ0FBVUEsSUFBckIsQ0FBaEI7QUFDQWlDLHlCQUFLMUIsR0FBTCxHQUFZMEIsS0FBS2hDLFFBQUwsQ0FBY00sR0FBZCxJQUFxQixHQUFqQztBQUNBLHdCQUFHLENBQUMwQixLQUFLaEMsUUFBTCxDQUFjTSxHQUFsQixFQUFzQjtBQUNwQjBCLDJCQUFLcEIsU0FBTCxHQUFpQixJQUFqQjtBQUNELHFCQUZELE1BRUs7QUFDSG9CLDJCQUFLcEIsU0FBTCxHQUFpQixLQUFqQjtBQUNEO0FBQ0RvQix5QkFBS0QsTUFBTDtBQUNELG1CQVRELE1BU087QUFDTEMseUJBQUtwQixTQUFMLEdBQWlCLElBQWpCO0FBQ0FvQix5QkFBS0QsTUFBTDtBQUNBLGtDQUFJa0IsS0FBSixDQUFVSixLQUFLSyxTQUFmO0FBQ0Q7QUFDRixpQkFmRDtBQWdCQTtBQUNGLG1CQUFLLE9BQUw7QUFBYTtBQUNYbEIscUJBQUtXLFVBQUwsQ0FBZ0JGLElBQWhCLEVBQXNCVCxLQUFLdEIsUUFBM0IsRUFBcUNzQixLQUFLekIsS0FBMUMsRUFBaUR5QixLQUFLeEIsUUFBdEQsRUFBZ0VvQyxJQUFoRSxDQUFxRSxnQkFBUTtBQUMzRSxzQkFBSUMsS0FBSzlDLElBQUwsQ0FBVStDLFVBQVYsSUFBd0IsU0FBNUIsRUFBdUM7QUFDckNkLHlCQUFLL0IsUUFBTCxHQUFnQjhDLEtBQUtDLEtBQUwsQ0FBV0gsS0FBSzlDLElBQUwsQ0FBVUEsSUFBckIsQ0FBaEI7QUFDQWlDLHlCQUFLRCxNQUFMO0FBQ0QsbUJBSEQsTUFHTztBQUNMLGtDQUFJa0IsS0FBSixDQUFVSixLQUFLSyxTQUFmO0FBQ0Q7QUFDRixpQkFQRDtBQVFBO0FBQ0YsbUJBQUssT0FBTDtBQUFhO0FBQ1hsQixxQkFBS1csVUFBTCxDQUFnQkYsSUFBaEIsRUFBc0JULEtBQUt0QixRQUEzQixFQUFxQ3NCLEtBQUt6QixLQUExQyxFQUFpRHlCLEtBQUt4QixRQUF0RCxFQUFnRW9DLElBQWhFLENBQXFFLGdCQUFRO0FBQzNFLHNCQUFJQyxLQUFLOUMsSUFBTCxDQUFVK0MsVUFBVixJQUF3QixTQUE1QixFQUF1QztBQUNyQ2QseUJBQUs5QixTQUFMLEdBQWlCNkMsS0FBS0MsS0FBTCxDQUFXSCxLQUFLOUMsSUFBTCxDQUFVQSxJQUFyQixDQUFqQjtBQUNBaUMseUJBQUtELE1BQUw7QUFDRCxtQkFIRCxNQUdPO0FBQ0wsa0NBQUlrQixLQUFKLENBQVVKLEtBQUtLLFNBQWY7QUFDRDtBQUNGLGlCQVBEO0FBUUE7QUFDRixtQkFBSyxPQUFMO0FBQWE7QUFDWGxCLHFCQUFLVyxVQUFMLENBQWdCRixJQUFoQixFQUFzQlQsS0FBS3RCLFFBQTNCLEVBQXFDc0IsS0FBS3pCLEtBQTFDLEVBQWlEeUIsS0FBS3hCLFFBQXRELEVBQWdFb0MsSUFBaEUsQ0FBcUUsZ0JBQVE7QUFDM0Usc0JBQUlDLEtBQUs5QyxJQUFMLENBQVUrQyxVQUFWLElBQXdCLFNBQTVCLEVBQXVDO0FBQ3JDZCx5QkFBSzdCLFFBQUwsR0FBZ0I0QyxLQUFLQyxLQUFMLENBQVdILEtBQUs5QyxJQUFMLENBQVVBLElBQXJCLENBQWhCO0FBQ0FpQyx5QkFBS0QsTUFBTDtBQUNELG1CQUhELE1BR087QUFDTCxrQ0FBSWtCLEtBQUosQ0FBVUosS0FBS0ssU0FBZjtBQUNEO0FBQ0YsaUJBUEQ7QUFRQTtBQUNGLG1CQUFLLE9BQUw7QUFBYTtBQUNYbEIscUJBQUtXLFVBQUwsQ0FBZ0JGLElBQWhCLEVBQXNCVCxLQUFLdEIsUUFBM0IsRUFBcUNzQixLQUFLekIsS0FBMUMsRUFBaUR5QixLQUFLeEIsUUFBdEQsRUFBZ0VvQyxJQUFoRSxDQUFxRSxnQkFBUTtBQUMzRSxzQkFBSUMsS0FBSzlDLElBQUwsQ0FBVStDLFVBQVYsSUFBd0IsU0FBNUIsRUFBdUM7QUFDckNkLHlCQUFLNUIsWUFBTCxHQUFvQjJDLEtBQUtDLEtBQUwsQ0FBV0gsS0FBSzlDLElBQUwsQ0FBVUEsSUFBckIsQ0FBcEI7QUFDQWlDLHlCQUFLRCxNQUFMO0FBQ0QsbUJBSEQsTUFHTztBQUNMLGtDQUFJa0IsS0FBSixDQUFVSixLQUFLSyxTQUFmO0FBQ0Q7QUFDRixpQkFQRDtBQVFBO0FBQ0YsbUJBQUssT0FBTDtBQUFhO0FBQ1hsQixxQkFBS1csVUFBTCxDQUFnQkYsSUFBaEIsRUFBc0JULEtBQUt0QixRQUEzQixFQUFxQ3NCLEtBQUt6QixLQUExQyxFQUFpRHlCLEtBQUt4QixRQUF0RCxFQUFnRW9DLElBQWhFLENBQXFFLGdCQUFRO0FBQzNFLHNCQUFJQyxLQUFLOUMsSUFBTCxDQUFVK0MsVUFBVixJQUF3QixTQUE1QixFQUF1QztBQUNyQ2QseUJBQUszQixXQUFMLEdBQW1CMEMsS0FBS0MsS0FBTCxDQUFXSCxLQUFLOUMsSUFBTCxDQUFVQSxJQUFyQixDQUFuQjtBQUNBaUMseUJBQUtELE1BQUw7QUFDRCxtQkFIRCxNQUdPO0FBQ0wsa0NBQUlrQixLQUFKLENBQVVKLEtBQUtLLFNBQWY7QUFDRDtBQUNGLGlCQVBEO0FBUUE7QUFyRUY7QUF1RUQsV0F4RUQ7QUF5RUgsU0F0RlM7QUF1RlZDLGNBQUssY0FBU04sSUFBVCxFQUFjO0FBQ2pCLHdCQUFJSSxLQUFKLENBQVVKLEtBQUs5QyxJQUFMLENBQVVtRCxTQUFwQjtBQUNEO0FBekZTLE9BQWQ7QUEyRkQ7Ozs7O0FBK0NDOzsyRkFDZUUsSSxFQUFLMUMsUSxFQUFTSCxLLEVBQU1DLFE7Ozs7Ozs7dUJBQ2hCLGNBQUk2QyxhQUFKLENBQWtCO0FBQ25DQyx5QkFBTztBQUNMQywwQkFBTTtBQUNKLG1DQUFhSCxJQURUO0FBRUosOEJBQVE7QUFGSixxQkFERDtBQUtMckQsMEJBQU07QUFDSiwrQkFBU1EsS0FETDtBQUVKLGtDQUFZQyxRQUZSO0FBR0osa0NBQVlFO0FBSFI7QUFMRDtBQUQ0QixpQkFBbEIsQzs7O0FBQWJtQyxvQjtpREFhQ0EsSTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFHVDs7Ozs7NEZBQ2V0QyxLLEVBQU1DLFEsRUFBU2dELE07Ozs7Ozs7dUJBQ1QsY0FBSUgsYUFBSixDQUFrQjtBQUNuQ0MseUJBQU87QUFDTEMsMEJBQUs7QUFDSCw4QkFBTyxHQURKO0FBRUgsbUNBQVk7QUFGVCxxQkFEQTtBQUtMeEQsMEJBQUs7QUFDSCxnQ0FBVXlELE1BRFA7QUFFSCxpQ0FBVSxLQUZQO0FBR0gsa0NBQVdoRCxRQUhSO0FBSUgsK0JBQVFEO0FBSkw7QUFMQTtBQUQ0QixpQkFBbEIsQzs7O0FBQWJzQyxvQjtrREFjQ0EsSTs7Ozs7Ozs7Ozs7Ozs7OztBQUVUOzs7Ozs7Ozs7OztBQUVVYixvQixHQUFPLEk7O3VCQUNNLGNBQUlLLE9BQUosQ0FBWTtBQUMzQmlCLHlCQUFPO0FBQ0NDLDBCQUFNO0FBQ0YsbUNBQWEsT0FEWDtBQUVGLDhCQUFRO0FBRk4scUJBRFA7QUFLQ3hELDBCQUFNO0FBQ0Ysa0NBQVlpQyxLQUFLeEIsUUFEZjtBQUVGLCtCQUFTd0IsS0FBS3pCO0FBRlo7QUFMUDtBQURvQixpQkFBWixDOzs7QUFBYnNDLG9COztBQVlOLG9CQUFHQSxLQUFLOUMsSUFBTCxDQUFVK0MsVUFBVixJQUF3QixTQUEzQixFQUFzQztBQUNsQyxzQkFBR0QsS0FBSzlDLElBQUwsQ0FBVUEsSUFBVixDQUFlVSxPQUFsQixFQUEwQjtBQUN0QnVCLHlCQUFLbEIsYUFBTCxHQUFxQixJQUFyQjtBQUNILG1CQUZELE1BRUs7QUFDRGtCLHlCQUFLbEIsYUFBTCxHQUFxQixLQUFyQjtBQUNIO0FBQ0RrQix1QkFBS25CLG9CQUFMLEdBQTRCZ0MsS0FBSzlDLElBQUwsQ0FBVUEsSUFBVixDQUFlVSxPQUEzQztBQUNBdUIsdUJBQUtELE1BQUw7QUFDSCxpQkFSRCxNQVFLO0FBQ0QsZ0NBQUlrQixLQUFKLENBQVVKLEtBQUs5QyxJQUFMLENBQVVtRCxTQUFwQjtBQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBMU9pQyxlQUFLTyxJOztrQkFBeEI3RCxVIiwiZmlsZSI6InJlc3VtZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgd2VweSBmcm9tICd3ZXB5JztcclxuaW1wb3J0IGFwaSBmcm9tICcuLi8uLi9hcGkvYXBpJztcclxuaW1wb3J0IHRpcCBmcm9tICcuLi8uLi91dGlscy90aXAnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgcmVzdW1lUGFnZSBleHRlbmRzIHdlcHkucGFnZSB7XHJcblxyXG4gIGNvbmZpZyA9IHtcclxuICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogJ+aIkeeahOeugOWOhicsXHJcbiAgfVxyXG5cclxuICBkYXRhID0ge1xyXG4gICAgYmFzZUluZm86IHt9LCAgICAgIC8vIOWfuuacrOS/oeaBr1xyXG4gICAgam9iQXBwbHk6IHt9LCAgICAgIC8vIOaxguiBjOaEj+WQkVxyXG4gICAgd29ya0V4cGVyOiB7fSwgICAgIC8vIOW3peS9nOe7j+WOhlxyXG4gICAgZWR1RXhwZXI6IHt9LCAgICAgIC8vIOaVmeiCsue7j+WOhlxyXG4gICAgcHJvamVjdEV4cGVyOiB7fSwgIC8vIOmhueebrue7j+mqjFxyXG4gICAgY2VydGlmaWNhdGU6IHt9LCAgICAvLyDor4HkuaZcclxuICAgIHNleDogdHJ1ZSxcclxuICAgIHRva2VuOiAnJyxcclxuICAgIHRva2VuS2V5OiAnJyxcclxuICAgIGhlYWRpbWc6ICcnLFxyXG4gICAgcmVzdW1laWQ6ICcnLFxyXG4gICAgb3BlcmF0ZVNob3c6IGZhbHNlLFxyXG4gICAgc2V4U3RhdHVzOiBmYWxzZSxcclxuICAgIHRlbXBQb3J0cmFpdEZpbGVQYXRoOiAnJyxcclxuICAgIGhlYWRpbWdTdGF0dXM6ZmFsc2UsXHJcbiAgfVxyXG5cclxuICBvbkxvYWQob3B0aW9ucykge1xyXG4gICAgdGhpcy5yZXN1bWVpZCA9IG9wdGlvbnMucmVzdW1laWQ7XHJcbiAgICAvLyBjb25zb2xlLmxvZyh0aGlzLnJlc3VtZWlkKVxyXG4gICAgaWYob3B0aW9ucy5sb29rPT1cImp1c3RcIil7XHJcbiAgICAgIHRoaXMub3BlcmF0ZVNob3cgPSB0cnVlO1xyXG4gICAgfWVsc2V7XHJcbiAgICAgIHRoaXMub3BlcmF0ZVNob3cgPSBmYWxzZTtcclxuICAgIH1cclxuICAgIHRoaXMuJGFwcGx5KCk7XHJcbiAgICBjb25zdCB0aGF0ID0gdGhpcztcclxuICAgIC8vIOiOt+WPlueZu+W9leS/oeaBr1xyXG4gICAgd3guZ2V0U3RvcmFnZSh7XHJcbiAgICAgICAga2V5OiAnbG9naW5EYXRhJyxcclxuICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAgICAgdGhhdC50b2tlbiA9IHJlcy5kYXRhLnRva2VuO1xyXG4gICAgICAgICAgICB0aGF0LnRva2VuS2V5ID0gcmVzLmRhdGEudG9rZW5LZXk7XHJcbiAgICAgICAgICAgIHRoYXQuaGVhZGltZyA9IHJlcy5kYXRhLmRhdGEuaGVhZGltZztcclxuICAgICAgICAgICAgdGhhdC5nZXRQaW1nKCk7XHJcbiAgICAgICAgICAgIHRoYXQuJGFwcGx5KCk7XHJcbiAgICAgICAgICAgIC8vIOiOt+WPlueugOWOhuS/oeaBr1xyXG4gICAgICAgICAgICBpZihvcHRpb25zLnJlc3VtZWlkPT09dW5kZWZpbmVkKXtcclxuICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCBhcnIgPSBbXCJNMDAwM1wiLFwiTTAwMDRcIixcIk0wMDA1XCIsXCJNMDAwNlwiLFwiTTAwMDhcIixcIk0wMDEwXCJdXHJcbiAgICAgICAgICAgIGFyci5mb3JFYWNoKChpdGVtLGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgc3dpdGNoIChpdGVtKVxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBjYXNlIFwiTTAwMDNcIjovLyDln7rmnKzkv6Hmga9cclxuICAgICAgICAgICAgICAgIHRoYXQuZ2V0Sm9iSW5mbyhpdGVtLCB0aGF0LnJlc3VtZWlkLCB0aGF0LnRva2VuLCB0aGF0LnRva2VuS2V5KS50aGVuKGpzb24gPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAoanNvbi5kYXRhLnJldHVybkNvZGUgPT0gXCJBQUFBQUFBXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LmJhc2VJbmZvID0gSlNPTi5wYXJzZShqc29uLmRhdGEuZGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC5zZXggPSAodGhhdC5iYXNlSW5mby5zZXggPT0gXCLnlLdcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoIXRoYXQuYmFzZUluZm8uc2V4KXtcclxuICAgICAgICAgICAgICAgICAgICAgIHRoYXQuc2V4U3RhdHVzID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGhhdC5zZXhTdGF0dXMgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGF0LiRhcHBseSgpO1xyXG4gICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoYXQuc2V4U3RhdHVzID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LiRhcHBseSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRpcC5lcnJvcihqc29uLnJldHVybk1zZyk7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICBjYXNlIFwiTTAwMDRcIjovLyDmsYLogYzmhI/lkJFcclxuICAgICAgICAgICAgICAgIHRoYXQuZ2V0Sm9iSW5mbyhpdGVtLCB0aGF0LnJlc3VtZWlkLCB0aGF0LnRva2VuLCB0aGF0LnRva2VuS2V5KS50aGVuKGpzb24gPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAoanNvbi5kYXRhLnJldHVybkNvZGUgPT0gXCJBQUFBQUFBXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LmpvYkFwcGx5ID0gSlNPTi5wYXJzZShqc29uLmRhdGEuZGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aXAuZXJyb3IoanNvbi5yZXR1cm5Nc2cpO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgY2FzZSBcIk0wMDA1XCI6Ly8g5bel5L2c57uP5Y6GXHJcbiAgICAgICAgICAgICAgICB0aGF0LmdldEpvYkluZm8oaXRlbSwgdGhhdC5yZXN1bWVpZCwgdGhhdC50b2tlbiwgdGhhdC50b2tlbktleSkudGhlbihqc29uID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKGpzb24uZGF0YS5yZXR1cm5Db2RlID09IFwiQUFBQUFBQVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC53b3JrRXhwZXIgPSBKU09OLnBhcnNlKGpzb24uZGF0YS5kYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LiRhcHBseSgpO1xyXG4gICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRpcC5lcnJvcihqc29uLnJldHVybk1zZyk7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICBjYXNlIFwiTTAwMDZcIjovLyDmlZnogrLnu4/ljoZcclxuICAgICAgICAgICAgICAgIHRoYXQuZ2V0Sm9iSW5mbyhpdGVtLCB0aGF0LnJlc3VtZWlkLCB0aGF0LnRva2VuLCB0aGF0LnRva2VuS2V5KS50aGVuKGpzb24gPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAoanNvbi5kYXRhLnJldHVybkNvZGUgPT0gXCJBQUFBQUFBXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LmVkdUV4cGVyID0gSlNPTi5wYXJzZShqc29uLmRhdGEuZGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aXAuZXJyb3IoanNvbi5yZXR1cm5Nc2cpO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgY2FzZSBcIk0wMDA4XCI6Ly8g6aG555uu57uP6aqMXHJcbiAgICAgICAgICAgICAgICB0aGF0LmdldEpvYkluZm8oaXRlbSwgdGhhdC5yZXN1bWVpZCwgdGhhdC50b2tlbiwgdGhhdC50b2tlbktleSkudGhlbihqc29uID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKGpzb24uZGF0YS5yZXR1cm5Db2RlID09IFwiQUFBQUFBQVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC5wcm9qZWN0RXhwZXIgPSBKU09OLnBhcnNlKGpzb24uZGF0YS5kYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LiRhcHBseSgpO1xyXG4gICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRpcC5lcnJvcihqc29uLnJldHVybk1zZyk7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICBjYXNlIFwiTTAwMTBcIjovLyDor4HkuaZcclxuICAgICAgICAgICAgICAgIHRoYXQuZ2V0Sm9iSW5mbyhpdGVtLCB0aGF0LnJlc3VtZWlkLCB0aGF0LnRva2VuLCB0aGF0LnRva2VuS2V5KS50aGVuKGpzb24gPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAoanNvbi5kYXRhLnJldHVybkNvZGUgPT0gXCJBQUFBQUFBXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LmNlcnRpZmljYXRlID0gSlNPTi5wYXJzZShqc29uLmRhdGEuZGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aXAuZXJyb3IoanNvbi5yZXR1cm5Nc2cpO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZhaWw6ZnVuY3Rpb24oanNvbil7XHJcbiAgICAgICAgICB0aXAuZXJyb3IoanNvbi5kYXRhLnJldHVybk1zZyk7XHJcbiAgICAgICAgfVxyXG4gICAgfSlcclxuICB9XHJcbiAgbWV0aG9kcyA9IHtcclxuXHJcbiAgICAgICAgLy8g5Z+65pys5L+h5oGv57yW6L6R5paw5aKeXHJcbiAgICAgICAgZ29CYXNlSW5mbyAocmVzdW1laWQpIHtcclxuICAgICAgICAgICAgd3gubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICB1cmw6IGBiYXNlX2luZm8/cmVzdW1laWQ9JHtyZXN1bWVpZH1gXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgLy8g5rGC6IGM5oSP5ZCRXHJcbiAgICAgICAgZ29Kb2JXYW50IChyZXN1bWVpZCkge1xyXG4gICAgICAgICAgICB3eC5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgIHVybDogYGpvYl93YW50P3Jlc3VtZWlkPSR7cmVzdW1laWR9YFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIC8vIOW3peS9nOe7j+WOhlxyXG4gICAgICAgIGdvV29ya0V4cGVyICh3b3JraWQsIHJlc3VtZWlkKSB7XHJcbiAgICAgICAgICAgIHd4Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgdXJsOiBgd29ya19leHBlcj93b3JraWQ9JHt3b3JraWR9JnJlc3VtZWlkPSR7cmVzdW1laWR9YFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIC8vIOaVmeiCsue7j+WOhlxyXG4gICAgICAgIGdvRWR1RXhwZXIgKGVkdWNhdGlvbmlkLCByZXN1bWVpZCkge1xyXG4gICAgICAgICAgICB3eC5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgIHVybDogYGVkdV9leHBlcj9lZHVjYXRpb25pZD0ke2VkdWNhdGlvbmlkfSZyZXN1bWVpZD0ke3Jlc3VtZWlkfWBcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICAvLyDpobnnm67nu4/pqoxcclxuICAgICAgICBnb1Byb2plY3RFeHBlciAocHJvamVjdGlkLCByZXN1bWVpZCkge1xyXG4gICAgICAgICAgICB3eC5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgIHVybDogYHByb2plY3RfZXhwZXI/cHJvamVjdGlkPSR7cHJvamVjdGlkfSZyZXN1bWVpZD0ke3Jlc3VtZWlkfWBcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICAvLyDor4HkuaZcclxuICAgICAgICBnb0NlcnQgKGNlcnRpZCwgcmVzdW1laWQpIHtcclxuICAgICAgICAgICAgd3gubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICB1cmw6IGBjZXJ0aWZpY2F0ZT9jZXJ0aWQ9JHtjZXJ0aWR9JnJlc3VtZWlkPSR7cmVzdW1laWR9YFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9O1xyXG5cclxuICAgIC8v6I635Y+W5YWs5Y+46K+m5oOF5pWw5o2uXHJcbiAgYXN5bmMgZ2V0Sm9iSW5mbyhjb2RlLHJlc3VtZWlkLHRva2VuLHRva2VuS2V5KSB7XHJcbiAgICBjb25zdCBqc29uID0gYXdhaXQgYXBpLmdldFJlc3VtZUluZm8oe1xyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGhlYWQ6IHtcclxuICAgICAgICAgIFwidHJhbnNjb2RlXCI6IGNvZGUsXHJcbiAgICAgICAgICBcInR5cGVcIjogXCJoXCJcclxuICAgICAgICB9LFxyXG4gICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgIFwidG9rZW5cIjogdG9rZW4sXHJcbiAgICAgICAgICBcInRva2VuS2V5XCI6IHRva2VuS2V5LFxyXG4gICAgICAgICAgXCJyZXN1bWVpZFwiOiByZXN1bWVpZFxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiBqc29uO1xyXG4gIH1cclxuXHJcbiAgLy/kv67mlLnlpLTlg49cclxuICBhc3luYyBjaGFuZ1BpYyh0b2tlbix0b2tlbktleSxpbWdzcmMpIHtcclxuICAgIGNvbnN0IGpzb24gPSBhd2FpdCBhcGkuZ2V0UmVzdW1lSW5mbyh7XHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgaGVhZDp7XHJcbiAgICAgICAgICBcInR5cGVcIjpcImlcIixcclxuICAgICAgICAgIFwidHJhbnNjb2RlXCI6XCJQMDAzOFwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIGRhdGE6e1xyXG4gICAgICAgICAgXCJpbWdzcmNcIjogaW1nc3JjLFxyXG4gICAgICAgICAgXCJpbWd0eXBlXCI6XCJwbmdcIixcclxuICAgICAgICAgIFwidG9rZW5LZXlcIjp0b2tlbktleSxcclxuICAgICAgICAgIFwidG9rZW5cIjp0b2tlblxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiBqc29uO1xyXG4gIH1cclxuICAvL+iOt+WPluS4quS6uuS/oeaBr1xyXG4gIGFzeW5jIGdldFBpbWcoKSB7XHJcbiAgICAgIGNvbnN0IHRoYXQgPSB0aGlzO1xyXG4gICAgICBjb25zdCBqc29uID0gYXdhaXQgYXBpLmdldFBpbWcoe1xyXG4gICAgICAgICAgcXVlcnk6IHtcclxuICAgICAgICAgICAgICAgICAgaGVhZDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgXCJ0cmFuc2NvZGVcIjogXCJQMDA0MFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiaFwiXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgICAgICAgIFwidG9rZW5LZXlcIjogdGhhdC50b2tlbktleSxcclxuICAgICAgICAgICAgICAgICAgICAgIFwidG9rZW5cIjogdGhhdC50b2tlbixcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICAgaWYoanNvbi5kYXRhLnJldHVybkNvZGUgPT0gJ0FBQUFBQUEnKSB7XHJcbiAgICAgICAgICBpZihqc29uLmRhdGEuZGF0YS5oZWFkaW1nKXtcclxuICAgICAgICAgICAgICB0aGF0LmhlYWRpbWdTdGF0dXMgPSB0cnVlO1xyXG4gICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgdGhhdC5oZWFkaW1nU3RhdHVzID0gZmFsc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0aGF0LnRlbXBQb3J0cmFpdEZpbGVQYXRoID0ganNvbi5kYXRhLmRhdGEuaGVhZGltZztcclxuICAgICAgICAgIHRoYXQuJGFwcGx5KCk7XHJcbiAgICAgIH1lbHNle1xyXG4gICAgICAgICAgdGlwLmVycm9yKGpzb24uZGF0YS5yZXR1cm5Nc2cpO1xyXG4gICAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ==