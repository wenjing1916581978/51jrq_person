'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _api = require('./../../api/api.js');

var _api2 = _interopRequireDefault(_api);

var _tip = require('./../../utils/tip.js');

var _tip2 = _interopRequireDefault(_tip);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BaseInfo = function (_wepy$page) {
    _inherits(BaseInfo, _wepy$page);

    function BaseInfo() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, BaseInfo);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = BaseInfo.__proto__ || Object.getPrototypeOf(BaseInfo)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: '求职意向'
        }, _this.data = {
            jobnature: [],
            postids: [],
            sitecity: [],
            expectsalarycode: [],
            poststime: [],
            functions: "",
            selfremark: "",
            a_jobnature: "",
            a_postids: "",
            a_sitecity: "",
            a_expectsalarycode: "",
            a_poststime: "",
            jobnaturestatus: true,
            postidsstatus: true,
            sitecitystatus: true,
            expectsalarycodestatus: true,
            poststimestatus: true,
            index1: "",
            index2: "",
            index3: "",
            index4: "",
            index5: "",
            jobApply: {},
            token: "",
            tokenKey: "",
            resumeid: '',
            jobintentcode: ''
        }, _this.methods = {
            // 提交表单--基本信息编辑新增
            formSubmit: function formSubmit(e) {
                wx.showLoading({
                    title: '加载中'
                });
                var obj2 = {
                    "token": this.token,
                    "tokenKey": this.tokenKey,
                    "resumeid": this.resumeid
                };
                if (!obj2.resumeid) {
                    delete obj2['resumeid'];
                }
                var that = this;
                this.changeBaseInfo(e.detail.value, obj2).then(function (data) {
                    if (data.data && data.data.returnCode == "AAAAAAA") {
                        wx.redirectTo({
                            url: 'resume?resumeid=' + that.resumeid
                        });
                    } else {
                        _tip2.default.error(data.data.returnMsg);
                    }
                    wx.hideLoading();
                });
            },
            bindPickerChange1: function bindPickerChange1(e) {
                this.jobnaturestatus = false;
                this.index1 = e.detail.value;
                this.$apply();
            },
            bindPickerChange2: function bindPickerChange2(e) {
                this.postidsstatus = false;
                this.index2 = e.detail.value;
                this.$apply();
            },
            bindPickerChange3: function bindPickerChange3(e) {
                this.sitecitystatus = false;
                this.index3 = e.detail.value;
                this.$apply();
            },
            bindPickerChange4: function bindPickerChange4(e) {
                this.expectsalarycodestatus = false;
                this.index4 = e.detail.value;
                this.$apply();
            },
            bindPickerChange5: function bindPickerChange5(e) {
                this.poststimestatus = false;
                this.index5 = e.detail.value;
                this.$apply();
            }

            //获取简历基本信息
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(BaseInfo, [{
        key: 'onLoad',
        value: function onLoad(options) {
            var _this2 = this;

            this.resumeid = options.resumeid;
            this.$apply();
            var arr = ['DICT_JOB_JOBTYPE', 'DICT_COMP_INDUSTRY', 'DICT_COMP_CITY', 'DICT_RESUME_ESC', 'DICT_RESUME_POSTTIME'];
            var that = this;
            // 获取登录信息
            wx.getStorage({
                key: 'loginData',
                success: function success(res) {
                    that.token = res.data.token;
                    that.tokenKey = res.data.tokenKey;
                    that.$apply();
                    if (options.resumeid == '') {
                        return false;
                    }
                    //获取求职意向
                    that.getJobInfo(res.data.token, res.data.tokenKey, that.resumeid).then(function (json) {
                        if (json.data.returnCode == "AAAAAAA") {
                            var jobApply = JSON.parse(json.data.data);
                            that.jobApply = {
                                "jobnature": jobApply.jobnature,
                                "postids": jobApply.postids,
                                "sitecity": jobApply.sitecity,
                                "expectsalarycode": jobApply.expectsalarycode,
                                "poststime": jobApply.poststime,
                                "functions": jobApply.functions,
                                "selfremark": jobApply.selfremark
                            };
                            that.a_jobnature = jobApply.jobnature;
                            that.a_postids = jobApply.postids;
                            that.a_sitecity = jobApply.sitecity;
                            that.a_expectsalarycode = jobApply.expectsalarycode;
                            that.a_poststime = jobApply.poststime;
                            that.functions = jobApply.functions;
                            that.selfremark = jobApply.selfremark;
                            that.jobintentcode = jobApply.jobintentcode;
                            that.$apply();
                        } else {
                            _tip2.default.error(json.returnMsg);
                        }
                    });
                }
            });

            // 获取数据字典
            arr.forEach(function (item, index) {
                switch (item) {
                    case "DICT_COMP_CITY":
                        // 城市
                        _this2.getDict(item).then(function (json) {
                            if (json.data.returnCode == "AAAAAAA") {
                                var arr = [];
                                json.data.data.forEach(function (item, index) {
                                    arr.push(item.label);
                                });
                                that.sitecity = arr;
                                that.$apply();
                            } else {
                                _tip2.default.error(json.returnMsg);
                            }
                        });
                        break;
                    case "DICT_JOB_JOBTYPE":
                        // 工作类型
                        _this2.getDict(item).then(function (json) {
                            if (json.data.returnCode == "AAAAAAA") {
                                var arr = [];
                                json.data.data.forEach(function (item, index) {
                                    arr.push(item.label);
                                });
                                that.jobnature = arr;
                                that.$apply();
                            } else {
                                _tip2.default.error(json.returnMsg);
                            }
                        });
                        break;
                    case "DICT_COMP_INDUSTRY":
                        // 期望行业
                        _this2.getDict(item).then(function (json) {
                            if (json.data.returnCode == "AAAAAAA") {
                                var arr = [];
                                json.data.data.forEach(function (item, index) {
                                    arr.push(item.label);
                                });
                                that.postids = arr;
                                that.$apply();
                            } else {
                                _tip2.default.error(json.returnMsg);
                            }
                        });
                        break;
                    case "DICT_RESUME_ESC":
                        // 期望薪资
                        _this2.getDict(item).then(function (json) {
                            if (json.data.returnCode == "AAAAAAA") {
                                var arr = [];
                                json.data.data.forEach(function (item, index) {
                                    arr.push(item.label);
                                });
                                that.expectsalarycode = arr;
                                that.$apply();
                            } else {
                                _tip2.default.error(json.returnMsg);
                            }
                        });
                        break;
                    case "DICT_RESUME_POSTTIME":
                        // 到岗时间
                        _this2.getDict(item).then(function (json) {
                            if (json.data.returnCode == "AAAAAAA") {
                                var arr = [];
                                json.data.data.forEach(function (item, index) {
                                    arr.push(item.label);
                                });
                                that.poststime = arr;
                                that.$apply();
                            } else {
                                _tip2.default.error(json.returnMsg);
                            }
                        });
                        break;
                }
            });
        }
    }, {
        key: 'getJobInfo',
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(token, tokenKey, resumeid) {
                var json;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _api2.default.getResumeInfo({
                                    query: {
                                        head: {
                                            "transcode": "M0004",
                                            "type": "h"
                                        },
                                        data: {
                                            "token": token,
                                            "tokenKey": tokenKey,
                                            "resumeid": resumeid
                                        }
                                    }
                                });

                            case 2:
                                json = _context.sent;
                                return _context.abrupt('return', json);

                            case 4:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function getJobInfo(_x, _x2, _x3) {
                return _ref2.apply(this, arguments);
            }

            return getJobInfo;
        }()

        //获取数据字典

    }, {
        key: 'getDict',
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(code) {
                var json;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return _api2.default.getDictData({
                                    query: {
                                        head: {
                                            "transcode": "DC001",
                                            "type": "h"
                                        },
                                        data: {
                                            "groupcode": code,
                                            "selAll": "true"
                                        }
                                    }
                                });

                            case 2:
                                json = _context2.sent;
                                return _context2.abrupt('return', json);

                            case 4:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function getDict(_x4) {
                return _ref3.apply(this, arguments);
            }

            return getDict;
        }()
        //修改表单数据

    }, {
        key: 'changeBaseInfo',
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(obj, obj2) {
                var data, Key, resultObj, json;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                data = obj2;

                                for (Key in obj) {
                                    if (!obj[Key]) {
                                        delete obj[Key];
                                    }
                                }
                                resultObj = Object.assign(data, this.jobApply, obj);

                                if (this.jobintentcode) {
                                    resultObj.jobintentcode = this.jobintentcode;
                                }
                                _context3.next = 6;
                                return _api2.default.getResumeInfo({
                                    query: {
                                        head: {
                                            "transcode": "M0014",
                                            "type": "h"
                                        },
                                        data: resultObj
                                    }
                                });

                            case 6:
                                json = _context3.sent;
                                return _context3.abrupt('return', json);

                            case 8:
                            case 'end':
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function changeBaseInfo(_x5, _x6) {
                return _ref4.apply(this, arguments);
            }

            return changeBaseInfo;
        }()
    }]);

    return BaseInfo;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(BaseInfo , 'pages/personal/job_want'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImpvYl93YW50LmpzIl0sIm5hbWVzIjpbIkJhc2VJbmZvIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJqb2JuYXR1cmUiLCJwb3N0aWRzIiwic2l0ZWNpdHkiLCJleHBlY3RzYWxhcnljb2RlIiwicG9zdHN0aW1lIiwiZnVuY3Rpb25zIiwic2VsZnJlbWFyayIsImFfam9ibmF0dXJlIiwiYV9wb3N0aWRzIiwiYV9zaXRlY2l0eSIsImFfZXhwZWN0c2FsYXJ5Y29kZSIsImFfcG9zdHN0aW1lIiwiam9ibmF0dXJlc3RhdHVzIiwicG9zdGlkc3N0YXR1cyIsInNpdGVjaXR5c3RhdHVzIiwiZXhwZWN0c2FsYXJ5Y29kZXN0YXR1cyIsInBvc3RzdGltZXN0YXR1cyIsImluZGV4MSIsImluZGV4MiIsImluZGV4MyIsImluZGV4NCIsImluZGV4NSIsImpvYkFwcGx5IiwidG9rZW4iLCJ0b2tlbktleSIsInJlc3VtZWlkIiwiam9iaW50ZW50Y29kZSIsIm1ldGhvZHMiLCJmb3JtU3VibWl0IiwiZSIsInd4Iiwic2hvd0xvYWRpbmciLCJ0aXRsZSIsIm9iajIiLCJ0aGF0IiwiY2hhbmdlQmFzZUluZm8iLCJkZXRhaWwiLCJ2YWx1ZSIsInRoZW4iLCJyZXR1cm5Db2RlIiwicmVkaXJlY3RUbyIsInVybCIsImVycm9yIiwicmV0dXJuTXNnIiwiaGlkZUxvYWRpbmciLCJiaW5kUGlja2VyQ2hhbmdlMSIsIiRhcHBseSIsImJpbmRQaWNrZXJDaGFuZ2UyIiwiYmluZFBpY2tlckNoYW5nZTMiLCJiaW5kUGlja2VyQ2hhbmdlNCIsImJpbmRQaWNrZXJDaGFuZ2U1Iiwib3B0aW9ucyIsImFyciIsImdldFN0b3JhZ2UiLCJrZXkiLCJzdWNjZXNzIiwicmVzIiwiZ2V0Sm9iSW5mbyIsImpzb24iLCJKU09OIiwicGFyc2UiLCJmb3JFYWNoIiwiaXRlbSIsImluZGV4IiwiZ2V0RGljdCIsInB1c2giLCJsYWJlbCIsImdldFJlc3VtZUluZm8iLCJxdWVyeSIsImhlYWQiLCJjb2RlIiwiZ2V0RGljdERhdGEiLCJvYmoiLCJLZXkiLCJyZXN1bHRPYmoiLCJPYmplY3QiLCJhc3NpZ24iLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDRTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBRXFCQSxROzs7Ozs7Ozs7Ozs7Ozs4TEFFbkJDLE0sR0FBUztBQUNUQyxvQ0FBd0I7QUFEZixTLFFBSVRDLEksR0FBTztBQUNIQyx1QkFBVyxFQURSO0FBRUhDLHFCQUFTLEVBRk47QUFHSEMsc0JBQVUsRUFIUDtBQUlIQyw4QkFBa0IsRUFKZjtBQUtIQyx1QkFBVyxFQUxSO0FBTUhDLHVCQUFXLEVBTlI7QUFPSEMsd0JBQVcsRUFQUjtBQVFIQyx5QkFBYSxFQVJWO0FBU0hDLHVCQUFXLEVBVFI7QUFVSEMsd0JBQVksRUFWVDtBQVdIQyxnQ0FBb0IsRUFYakI7QUFZSEMseUJBQWEsRUFaVjtBQWFIQyw2QkFBaUIsSUFiZDtBQWNIQywyQkFBZSxJQWRaO0FBZUhDLDRCQUFnQixJQWZiO0FBZ0JIQyxvQ0FBd0IsSUFoQnJCO0FBaUJIQyw2QkFBaUIsSUFqQmQ7QUFrQkhDLG9CQUFRLEVBbEJMO0FBbUJIQyxvQkFBUSxFQW5CTDtBQW9CSEMsb0JBQVEsRUFwQkw7QUFxQkhDLG9CQUFRLEVBckJMO0FBc0JIQyxvQkFBUSxFQXRCTDtBQXVCSEMsc0JBQVUsRUF2QlA7QUF3QkhDLG1CQUFPLEVBeEJKO0FBeUJIQyxzQkFBVSxFQXpCUDtBQTBCSEMsc0JBQVMsRUExQk47QUEyQkhDLDJCQUFjO0FBM0JYLFMsUUF5SlBDLE8sR0FBVTtBQUNOO0FBQ0FDLHdCQUFZLG9CQUFTQyxDQUFULEVBQVk7QUFDcEJDLG1CQUFHQyxXQUFILENBQWU7QUFDWEMsMkJBQU87QUFESSxpQkFBZjtBQUdBLG9CQUFJQyxPQUFPO0FBQ1AsNkJBQVMsS0FBS1YsS0FEUDtBQUVQLGdDQUFZLEtBQUtDLFFBRlY7QUFHUCxnQ0FBWSxLQUFLQztBQUhWLGlCQUFYO0FBS0Esb0JBQUcsQ0FBQ1EsS0FBS1IsUUFBVCxFQUFrQjtBQUNkLDJCQUFPUSxLQUFLLFVBQUwsQ0FBUDtBQUNIO0FBQ0Qsb0JBQU1DLE9BQU8sSUFBYjtBQUNBLHFCQUFLQyxjQUFMLENBQW9CTixFQUFFTyxNQUFGLENBQVNDLEtBQTdCLEVBQW1DSixJQUFuQyxFQUF5Q0ssSUFBekMsQ0FBOEMsZ0JBQU07QUFDaEQsd0JBQUd2QyxLQUFLQSxJQUFMLElBQWFBLEtBQUtBLElBQUwsQ0FBVXdDLFVBQVYsSUFBd0IsU0FBeEMsRUFBbUQ7QUFDL0NULDJCQUFHVSxVQUFILENBQWM7QUFDVkMsc0RBQXdCUCxLQUFLVDtBQURuQix5QkFBZDtBQUdILHFCQUpELE1BSUs7QUFDRCxzQ0FBSWlCLEtBQUosQ0FBVTNDLEtBQUtBLElBQUwsQ0FBVTRDLFNBQXBCO0FBQ0g7QUFDRGIsdUJBQUdjLFdBQUg7QUFDSCxpQkFURDtBQVVILGFBekJLO0FBMEJOQywrQkFBbUIsMkJBQVNoQixDQUFULEVBQVk7QUFDM0IscUJBQUtqQixlQUFMLEdBQXVCLEtBQXZCO0FBQ0EscUJBQUtLLE1BQUwsR0FBY1ksRUFBRU8sTUFBRixDQUFTQyxLQUF2QjtBQUNBLHFCQUFLUyxNQUFMO0FBQ0gsYUE5Qks7QUErQk5DLCtCQUFtQiwyQkFBU2xCLENBQVQsRUFBWTtBQUMzQixxQkFBS2hCLGFBQUwsR0FBcUIsS0FBckI7QUFDQSxxQkFBS0ssTUFBTCxHQUFjVyxFQUFFTyxNQUFGLENBQVNDLEtBQXZCO0FBQ0EscUJBQUtTLE1BQUw7QUFDSCxhQW5DSztBQW9DTkUsK0JBQW1CLDJCQUFTbkIsQ0FBVCxFQUFZO0FBQzNCLHFCQUFLZixjQUFMLEdBQXNCLEtBQXRCO0FBQ0EscUJBQUtLLE1BQUwsR0FBY1UsRUFBRU8sTUFBRixDQUFTQyxLQUF2QjtBQUNBLHFCQUFLUyxNQUFMO0FBQ0gsYUF4Q0s7QUF5Q05HLCtCQUFtQiwyQkFBU3BCLENBQVQsRUFBWTtBQUMzQixxQkFBS2Qsc0JBQUwsR0FBOEIsS0FBOUI7QUFDQSxxQkFBS0ssTUFBTCxHQUFjUyxFQUFFTyxNQUFGLENBQVNDLEtBQXZCO0FBQ0EscUJBQUtTLE1BQUw7QUFDSCxhQTdDSztBQThDTkksK0JBQW1CLDJCQUFTckIsQ0FBVCxFQUFZO0FBQzNCLHFCQUFLYixlQUFMLEdBQXVCLEtBQXZCO0FBQ0EscUJBQUtLLE1BQUwsR0FBY1EsRUFBRU8sTUFBRixDQUFTQyxLQUF2QjtBQUNBLHFCQUFLUyxNQUFMO0FBQ0g7O0FBR0w7QUFyRFUsUzs7Ozs7K0JBM0hISyxPLEVBQVM7QUFBQTs7QUFDWixpQkFBSzFCLFFBQUwsR0FBZ0IwQixRQUFRMUIsUUFBeEI7QUFDQSxpQkFBS3FCLE1BQUw7QUFDQSxnQkFBTU0sTUFBTSxDQUFDLGtCQUFELEVBQW9CLG9CQUFwQixFQUF5QyxnQkFBekMsRUFBMEQsaUJBQTFELEVBQTRFLHNCQUE1RSxDQUFaO0FBQ0EsZ0JBQU1sQixPQUFPLElBQWI7QUFDQTtBQUNBSixlQUFHdUIsVUFBSCxDQUFjO0FBQ1ZDLHFCQUFLLFdBREs7QUFFVkMseUJBQVMsaUJBQVNDLEdBQVQsRUFBYztBQUNuQnRCLHlCQUFLWCxLQUFMLEdBQWFpQyxJQUFJekQsSUFBSixDQUFTd0IsS0FBdEI7QUFDQVcseUJBQUtWLFFBQUwsR0FBZ0JnQyxJQUFJekQsSUFBSixDQUFTeUIsUUFBekI7QUFDQVUseUJBQUtZLE1BQUw7QUFDQSx3QkFBR0ssUUFBUTFCLFFBQVIsSUFBa0IsRUFBckIsRUFBd0I7QUFDdEIsK0JBQU8sS0FBUDtBQUNEO0FBQ0Q7QUFDQVMseUJBQUt1QixVQUFMLENBQWdCRCxJQUFJekQsSUFBSixDQUFTd0IsS0FBekIsRUFBZ0NpQyxJQUFJekQsSUFBSixDQUFTeUIsUUFBekMsRUFBbURVLEtBQUtULFFBQXhELEVBQWtFYSxJQUFsRSxDQUF1RSxnQkFBUTtBQUMvRSw0QkFBSW9CLEtBQUszRCxJQUFMLENBQVV3QyxVQUFWLElBQXdCLFNBQTVCLEVBQXVDO0FBQ25DLGdDQUFJakIsV0FBV3FDLEtBQUtDLEtBQUwsQ0FBV0YsS0FBSzNELElBQUwsQ0FBVUEsSUFBckIsQ0FBZjtBQUNBbUMsaUNBQUtaLFFBQUwsR0FBZ0I7QUFDWiw2Q0FBYUEsU0FBU3RCLFNBRFY7QUFFWiwyQ0FBV3NCLFNBQVNyQixPQUZSO0FBR1osNENBQVlxQixTQUFTcEIsUUFIVDtBQUlaLG9EQUFvQm9CLFNBQVNuQixnQkFKakI7QUFLWiw2Q0FBYW1CLFNBQVNsQixTQUxWO0FBTVosNkNBQWFrQixTQUFTakIsU0FOVjtBQU9aLDhDQUFjaUIsU0FBU2hCO0FBUFgsNkJBQWhCO0FBU0E0QixpQ0FBSzNCLFdBQUwsR0FBbUJlLFNBQVN0QixTQUE1QjtBQUNBa0MsaUNBQUsxQixTQUFMLEdBQWlCYyxTQUFTckIsT0FBMUI7QUFDQWlDLGlDQUFLekIsVUFBTCxHQUFrQmEsU0FBU3BCLFFBQTNCO0FBQ0FnQyxpQ0FBS3hCLGtCQUFMLEdBQTBCWSxTQUFTbkIsZ0JBQW5DO0FBQ0ErQixpQ0FBS3ZCLFdBQUwsR0FBbUJXLFNBQVNsQixTQUE1QjtBQUNBOEIsaUNBQUs3QixTQUFMLEdBQWlCaUIsU0FBU2pCLFNBQTFCO0FBQ0E2QixpQ0FBSzVCLFVBQUwsR0FBa0JnQixTQUFTaEIsVUFBM0I7QUFDQTRCLGlDQUFLUixhQUFMLEdBQXFCSixTQUFTSSxhQUE5QjtBQUNBUSxpQ0FBS1ksTUFBTDtBQUNILHlCQXBCRCxNQW9CTztBQUNILDBDQUFJSixLQUFKLENBQVVnQixLQUFLZixTQUFmO0FBQ0g7QUFDQSxxQkF4QkQ7QUF5Qkg7QUFuQ1MsYUFBZDs7QUF1Q0E7QUFDSVMsZ0JBQUlTLE9BQUosQ0FBWSxVQUFDQyxJQUFELEVBQU1DLEtBQU4sRUFBZ0I7QUFDNUIsd0JBQVFELElBQVI7QUFFQSx5QkFBSyxnQkFBTDtBQUFzQjtBQUNsQiwrQkFBS0UsT0FBTCxDQUFhRixJQUFiLEVBQW1CeEIsSUFBbkIsQ0FBd0IsZ0JBQVE7QUFDaEMsZ0NBQUlvQixLQUFLM0QsSUFBTCxDQUFVd0MsVUFBVixJQUF3QixTQUE1QixFQUF1QztBQUNuQyxvQ0FBSWEsTUFBTSxFQUFWO0FBQ0FNLHFDQUFLM0QsSUFBTCxDQUFVQSxJQUFWLENBQWU4RCxPQUFmLENBQXVCLFVBQUNDLElBQUQsRUFBTUMsS0FBTixFQUFjO0FBQ2pDWCx3Q0FBSWEsSUFBSixDQUFTSCxLQUFLSSxLQUFkO0FBQ0gsaUNBRkQ7QUFHQWhDLHFDQUFLaEMsUUFBTCxHQUFnQmtELEdBQWhCO0FBQ0FsQixxQ0FBS1ksTUFBTDtBQUNILDZCQVBELE1BT087QUFDSCw4Q0FBSUosS0FBSixDQUFVZ0IsS0FBS2YsU0FBZjtBQUNIO0FBQ0EseUJBWEQ7QUFZQTtBQUNKLHlCQUFLLGtCQUFMO0FBQXdCO0FBQ3BCLCtCQUFLcUIsT0FBTCxDQUFhRixJQUFiLEVBQW1CeEIsSUFBbkIsQ0FBd0IsZ0JBQVE7QUFDaEMsZ0NBQUlvQixLQUFLM0QsSUFBTCxDQUFVd0MsVUFBVixJQUF3QixTQUE1QixFQUF1QztBQUNuQyxvQ0FBSWEsTUFBTSxFQUFWO0FBQ0FNLHFDQUFLM0QsSUFBTCxDQUFVQSxJQUFWLENBQWU4RCxPQUFmLENBQXVCLFVBQUNDLElBQUQsRUFBTUMsS0FBTixFQUFjO0FBQ2pDWCx3Q0FBSWEsSUFBSixDQUFTSCxLQUFLSSxLQUFkO0FBQ0gsaUNBRkQ7QUFHQWhDLHFDQUFLbEMsU0FBTCxHQUFpQm9ELEdBQWpCO0FBQ0FsQixxQ0FBS1ksTUFBTDtBQUNILDZCQVBELE1BT087QUFDSCw4Q0FBSUosS0FBSixDQUFVZ0IsS0FBS2YsU0FBZjtBQUNIO0FBQ0EseUJBWEQ7QUFZQTtBQUNKLHlCQUFLLG9CQUFMO0FBQTBCO0FBQ3RCLCtCQUFLcUIsT0FBTCxDQUFhRixJQUFiLEVBQW1CeEIsSUFBbkIsQ0FBd0IsZ0JBQVE7QUFDaEMsZ0NBQUlvQixLQUFLM0QsSUFBTCxDQUFVd0MsVUFBVixJQUF3QixTQUE1QixFQUF1QztBQUNuQyxvQ0FBSWEsTUFBTSxFQUFWO0FBQ0FNLHFDQUFLM0QsSUFBTCxDQUFVQSxJQUFWLENBQWU4RCxPQUFmLENBQXVCLFVBQUNDLElBQUQsRUFBTUMsS0FBTixFQUFjO0FBQ2pDWCx3Q0FBSWEsSUFBSixDQUFTSCxLQUFLSSxLQUFkO0FBQ0gsaUNBRkQ7QUFHQWhDLHFDQUFLakMsT0FBTCxHQUFlbUQsR0FBZjtBQUNBbEIscUNBQUtZLE1BQUw7QUFDSCw2QkFQRCxNQU9PO0FBQ0gsOENBQUlKLEtBQUosQ0FBVWdCLEtBQUtmLFNBQWY7QUFDSDtBQUNBLHlCQVhEO0FBWUE7QUFDSix5QkFBSyxpQkFBTDtBQUF1QjtBQUNuQiwrQkFBS3FCLE9BQUwsQ0FBYUYsSUFBYixFQUFtQnhCLElBQW5CLENBQXdCLGdCQUFRO0FBQ2hDLGdDQUFJb0IsS0FBSzNELElBQUwsQ0FBVXdDLFVBQVYsSUFBd0IsU0FBNUIsRUFBdUM7QUFDbkMsb0NBQUlhLE1BQU0sRUFBVjtBQUNBTSxxQ0FBSzNELElBQUwsQ0FBVUEsSUFBVixDQUFlOEQsT0FBZixDQUF1QixVQUFDQyxJQUFELEVBQU1DLEtBQU4sRUFBYztBQUNqQ1gsd0NBQUlhLElBQUosQ0FBU0gsS0FBS0ksS0FBZDtBQUNILGlDQUZEO0FBR0FoQyxxQ0FBSy9CLGdCQUFMLEdBQXdCaUQsR0FBeEI7QUFDQWxCLHFDQUFLWSxNQUFMO0FBQ0gsNkJBUEQsTUFPTztBQUNILDhDQUFJSixLQUFKLENBQVVnQixLQUFLZixTQUFmO0FBQ0g7QUFDQSx5QkFYRDtBQVlBO0FBQ0oseUJBQUssc0JBQUw7QUFBNEI7QUFDeEIsK0JBQUtxQixPQUFMLENBQWFGLElBQWIsRUFBbUJ4QixJQUFuQixDQUF3QixnQkFBUTtBQUNoQyxnQ0FBSW9CLEtBQUszRCxJQUFMLENBQVV3QyxVQUFWLElBQXdCLFNBQTVCLEVBQXVDO0FBQ25DLG9DQUFJYSxNQUFNLEVBQVY7QUFDQU0scUNBQUszRCxJQUFMLENBQVVBLElBQVYsQ0FBZThELE9BQWYsQ0FBdUIsVUFBQ0MsSUFBRCxFQUFNQyxLQUFOLEVBQWM7QUFDakNYLHdDQUFJYSxJQUFKLENBQVNILEtBQUtJLEtBQWQ7QUFDSCxpQ0FGRDtBQUdBaEMscUNBQUs5QixTQUFMLEdBQWlCZ0QsR0FBakI7QUFDQWxCLHFDQUFLWSxNQUFMO0FBQ0gsNkJBUEQsTUFPTztBQUNILDhDQUFJSixLQUFKLENBQVVnQixLQUFLZixTQUFmO0FBQ0g7QUFDQSx5QkFYRDtBQVlBO0FBdkVKO0FBeUVILGFBMUVHO0FBMkVQOzs7O2lHQXdEZ0JwQixLLEVBQU9DLFEsRUFBVUMsUTs7Ozs7Ozt1Q0FDWCxjQUFJMEMsYUFBSixDQUFrQjtBQUNyQ0MsMkNBQU87QUFDQ0MsOENBQU07QUFDRix5REFBYSxPQURYO0FBRUYsb0RBQVE7QUFGTix5Q0FEUDtBQUtDdEUsOENBQU07QUFDRixxREFBU3dCLEtBRFA7QUFFRix3REFBWUMsUUFGVjtBQUdGLHdEQUFZQztBQUhWO0FBTFA7QUFEOEIsaUNBQWxCLEM7OztBQUFiaUMsb0M7aUVBYUNBLEk7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBR1g7Ozs7O2tHQUNjWSxJOzs7Ozs7O3VDQUNTLGNBQUlDLFdBQUosQ0FBZ0I7QUFDbkNILDJDQUFPO0FBQ0NDLDhDQUFNO0FBQ0YseURBQWEsT0FEWDtBQUVGLG9EQUFRO0FBRk4seUNBRFA7QUFLQ3RFLDhDQUFNO0FBQ0YseURBQWF1RSxJQURYO0FBRUYsc0RBQVU7QUFGUjtBQUxQO0FBRDRCLGlDQUFoQixDOzs7QUFBYlosb0M7a0VBWUNBLEk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFWDs7Ozs7a0dBQ3FCYyxHLEVBQUl2QyxJOzs7Ozs7QUFDakJsQyxvQyxHQUFPa0MsSTs7QUFDWCxxQ0FBU3dDLEdBQVQsSUFBZ0JELEdBQWhCLEVBQW9CO0FBQ2hCLHdDQUFHLENBQUNBLElBQUlDLEdBQUosQ0FBSixFQUFhO0FBQ1QsK0NBQU9ELElBQUlDLEdBQUosQ0FBUDtBQUNIO0FBQ0o7QUFDR0MseUMsR0FBWUMsT0FBT0MsTUFBUCxDQUFjN0UsSUFBZCxFQUFvQixLQUFLdUIsUUFBekIsRUFBbUNrRCxHQUFuQyxDOztBQUNoQixvQ0FBRyxLQUFLOUMsYUFBUixFQUFzQjtBQUNsQmdELDhDQUFVaEQsYUFBVixHQUEwQixLQUFLQSxhQUEvQjtBQUNIOzt1Q0FDa0IsY0FBSXlDLGFBQUosQ0FBa0I7QUFDckNDLDJDQUFPO0FBQ0NDLDhDQUFNO0FBQ0YseURBQWEsT0FEWDtBQUVGLG9EQUFRO0FBRk4seUNBRFA7QUFLQ3RFLDhDQUFNMkU7QUFMUDtBQUQ4QixpQ0FBbEIsQzs7O0FBQWJoQixvQztrRUFTQ0EsSTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTNReUIsZUFBS21CLEk7O2tCQUF0QmpGLFEiLCJmaWxlIjoiam9iX3dhbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tICd3ZXB5J1xyXG4gIGltcG9ydCBhcGkgZnJvbSAnLi4vLi4vYXBpL2FwaSc7XHJcbiAgaW1wb3J0IHRpcCBmcm9tICcuLi8uLi91dGlscy90aXAnO1xyXG5cclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBCYXNlSW5mbyBleHRlbmRzIHdlcHkucGFnZSB7XHJcblxyXG4gICAgY29uZmlnID0ge1xyXG4gICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogJ+axguiBjOaEj+WQkScsXHJcbiAgICB9XHJcblxyXG4gICAgZGF0YSA9IHtcclxuICAgICAgICBqb2JuYXR1cmU6IFtdLFxyXG4gICAgICAgIHBvc3RpZHM6IFtdLFxyXG4gICAgICAgIHNpdGVjaXR5OiBbXSxcclxuICAgICAgICBleHBlY3RzYWxhcnljb2RlOiBbXSxcclxuICAgICAgICBwb3N0c3RpbWU6IFtdLFxyXG4gICAgICAgIGZ1bmN0aW9uczogXCJcIixcclxuICAgICAgICBzZWxmcmVtYXJrOlwiXCIsXHJcbiAgICAgICAgYV9qb2JuYXR1cmU6IFwiXCIsXHJcbiAgICAgICAgYV9wb3N0aWRzOiBcIlwiLFxyXG4gICAgICAgIGFfc2l0ZWNpdHk6IFwiXCIsXHJcbiAgICAgICAgYV9leHBlY3RzYWxhcnljb2RlOiBcIlwiLFxyXG4gICAgICAgIGFfcG9zdHN0aW1lOiBcIlwiLFxyXG4gICAgICAgIGpvYm5hdHVyZXN0YXR1czogdHJ1ZSxcclxuICAgICAgICBwb3N0aWRzc3RhdHVzOiB0cnVlLFxyXG4gICAgICAgIHNpdGVjaXR5c3RhdHVzOiB0cnVlLFxyXG4gICAgICAgIGV4cGVjdHNhbGFyeWNvZGVzdGF0dXM6IHRydWUsXHJcbiAgICAgICAgcG9zdHN0aW1lc3RhdHVzOiB0cnVlLFxyXG4gICAgICAgIGluZGV4MTogXCJcIixcclxuICAgICAgICBpbmRleDI6IFwiXCIsXHJcbiAgICAgICAgaW5kZXgzOiBcIlwiLFxyXG4gICAgICAgIGluZGV4NDogXCJcIixcclxuICAgICAgICBpbmRleDU6IFwiXCIsXHJcbiAgICAgICAgam9iQXBwbHk6IHt9LFxyXG4gICAgICAgIHRva2VuOiBcIlwiLFxyXG4gICAgICAgIHRva2VuS2V5OiBcIlwiLFxyXG4gICAgICAgIHJlc3VtZWlkOicnLFxyXG4gICAgICAgIGpvYmludGVudGNvZGU6JydcclxuICAgIH1cclxuXHJcbiAgICBvbkxvYWQob3B0aW9ucykge1xyXG4gICAgICAgIHRoaXMucmVzdW1laWQgPSBvcHRpb25zLnJlc3VtZWlkO1xyXG4gICAgICAgIHRoaXMuJGFwcGx5KCk7XHJcbiAgICAgICAgY29uc3QgYXJyID0gWydESUNUX0pPQl9KT0JUWVBFJywnRElDVF9DT01QX0lORFVTVFJZJywnRElDVF9DT01QX0NJVFknLCdESUNUX1JFU1VNRV9FU0MnLCdESUNUX1JFU1VNRV9QT1NUVElNRSddXHJcbiAgICAgICAgY29uc3QgdGhhdCA9IHRoaXM7XHJcbiAgICAgICAgLy8g6I635Y+W55m75b2V5L+h5oGvXHJcbiAgICAgICAgd3guZ2V0U3RvcmFnZSh7XHJcbiAgICAgICAgICAgIGtleTogJ2xvZ2luRGF0YScsXHJcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgICAgICAgICAgdGhhdC50b2tlbiA9IHJlcy5kYXRhLnRva2VuO1xyXG4gICAgICAgICAgICAgICAgdGhhdC50b2tlbktleSA9IHJlcy5kYXRhLnRva2VuS2V5O1xyXG4gICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgIGlmKG9wdGlvbnMucmVzdW1laWQ9PScnKXtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvL+iOt+WPluaxguiBjOaEj+WQkVxyXG4gICAgICAgICAgICAgICAgdGhhdC5nZXRKb2JJbmZvKHJlcy5kYXRhLnRva2VuLCByZXMuZGF0YS50b2tlbktleSwgdGhhdC5yZXN1bWVpZCkudGhlbihqc29uID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChqc29uLmRhdGEucmV0dXJuQ29kZSA9PSBcIkFBQUFBQUFcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBqb2JBcHBseSA9IEpTT04ucGFyc2UoanNvbi5kYXRhLmRhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoYXQuam9iQXBwbHkgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiam9ibmF0dXJlXCI6IGpvYkFwcGx5LmpvYm5hdHVyZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJwb3N0aWRzXCI6IGpvYkFwcGx5LnBvc3RpZHMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwic2l0ZWNpdHlcIjogam9iQXBwbHkuc2l0ZWNpdHksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiZXhwZWN0c2FsYXJ5Y29kZVwiOiBqb2JBcHBseS5leHBlY3RzYWxhcnljb2RlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcInBvc3RzdGltZVwiOiBqb2JBcHBseS5wb3N0c3RpbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiZnVuY3Rpb25zXCI6IGpvYkFwcGx5LmZ1bmN0aW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJzZWxmcmVtYXJrXCI6IGpvYkFwcGx5LnNlbGZyZW1hcmtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC5hX2pvYm5hdHVyZSA9IGpvYkFwcGx5LmpvYm5hdHVyZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LmFfcG9zdGlkcyA9IGpvYkFwcGx5LnBvc3RpZHM7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC5hX3NpdGVjaXR5ID0gam9iQXBwbHkuc2l0ZWNpdHk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC5hX2V4cGVjdHNhbGFyeWNvZGUgPSBqb2JBcHBseS5leHBlY3RzYWxhcnljb2RlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoYXQuYV9wb3N0c3RpbWUgPSBqb2JBcHBseS5wb3N0c3RpbWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC5mdW5jdGlvbnMgPSBqb2JBcHBseS5mdW5jdGlvbnM7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC5zZWxmcmVtYXJrID0gam9iQXBwbHkuc2VsZnJlbWFyaztcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LmpvYmludGVudGNvZGUgPSBqb2JBcHBseS5qb2JpbnRlbnRjb2RlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoYXQuJGFwcGx5KCk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRpcC5lcnJvcihqc29uLnJldHVybk1zZyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuXHJcblxyXG4gICAgICAgIC8vIOiOt+WPluaVsOaNruWtl+WFuFxyXG4gICAgICAgICAgICBhcnIuZm9yRWFjaCgoaXRlbSxpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKGl0ZW0pXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgY2FzZSBcIkRJQ1RfQ09NUF9DSVRZXCI6Ly8g5Z+O5biCXHJcbiAgICAgICAgICAgICAgICB0aGlzLmdldERpY3QoaXRlbSkudGhlbihqc29uID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChqc29uLmRhdGEucmV0dXJuQ29kZSA9PSBcIkFBQUFBQUFcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBhcnIgPSBbXVxyXG4gICAgICAgICAgICAgICAgICAgIGpzb24uZGF0YS5kYXRhLmZvckVhY2goKGl0ZW0saW5kZXgpPT57XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyci5wdXNoKGl0ZW0ubGFiZWwpXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LnNpdGVjaXR5ID0gYXJyO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoYXQuJGFwcGx5KCk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRpcC5lcnJvcihqc29uLnJldHVybk1zZyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJESUNUX0pPQl9KT0JUWVBFXCI6Ly8g5bel5L2c57G75Z6LXHJcbiAgICAgICAgICAgICAgICB0aGlzLmdldERpY3QoaXRlbSkudGhlbihqc29uID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChqc29uLmRhdGEucmV0dXJuQ29kZSA9PSBcIkFBQUFBQUFcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBhcnIgPSBbXVxyXG4gICAgICAgICAgICAgICAgICAgIGpzb24uZGF0YS5kYXRhLmZvckVhY2goKGl0ZW0saW5kZXgpPT57XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyci5wdXNoKGl0ZW0ubGFiZWwpXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LmpvYm5hdHVyZSA9IGFycjtcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LiRhcHBseSgpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aXAuZXJyb3IoanNvbi5yZXR1cm5Nc2cpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIFwiRElDVF9DT01QX0lORFVTVFJZXCI6Ly8g5pyf5pyb6KGM5LiaXHJcbiAgICAgICAgICAgICAgICB0aGlzLmdldERpY3QoaXRlbSkudGhlbihqc29uID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChqc29uLmRhdGEucmV0dXJuQ29kZSA9PSBcIkFBQUFBQUFcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBhcnIgPSBbXVxyXG4gICAgICAgICAgICAgICAgICAgIGpzb24uZGF0YS5kYXRhLmZvckVhY2goKGl0ZW0saW5kZXgpPT57XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyci5wdXNoKGl0ZW0ubGFiZWwpXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB0aGF0LnBvc3RpZHMgPSBhcnI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGlwLmVycm9yKGpzb24ucmV0dXJuTXNnKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcIkRJQ1RfUkVTVU1FX0VTQ1wiOi8vIOacn+acm+iWqui1hFxyXG4gICAgICAgICAgICAgICAgdGhpcy5nZXREaWN0KGl0ZW0pLnRoZW4oanNvbiA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoanNvbi5kYXRhLnJldHVybkNvZGUgPT0gXCJBQUFBQUFBXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgYXJyID0gW11cclxuICAgICAgICAgICAgICAgICAgICBqc29uLmRhdGEuZGF0YS5mb3JFYWNoKChpdGVtLGluZGV4KT0+e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcnIucHVzaChpdGVtLmxhYmVsKVxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC5leHBlY3RzYWxhcnljb2RlID0gYXJyO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoYXQuJGFwcGx5KCk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRpcC5lcnJvcihqc29uLnJldHVybk1zZyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJESUNUX1JFU1VNRV9QT1NUVElNRVwiOi8vIOWIsOWyl+aXtumXtFxyXG4gICAgICAgICAgICAgICAgdGhpcy5nZXREaWN0KGl0ZW0pLnRoZW4oanNvbiA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoanNvbi5kYXRhLnJldHVybkNvZGUgPT0gXCJBQUFBQUFBXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgYXJyID0gW11cclxuICAgICAgICAgICAgICAgICAgICBqc29uLmRhdGEuZGF0YS5mb3JFYWNoKChpdGVtLGluZGV4KT0+e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcnIucHVzaChpdGVtLmxhYmVsKVxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC5wb3N0c3RpbWUgPSBhcnI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGlwLmVycm9yKGpzb24ucmV0dXJuTXNnKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgLy8g5o+Q5Lqk6KGo5Y2VLS3ln7rmnKzkv6Hmga/nvJbovpHmlrDlop5cclxuICAgICAgICBmb3JtU3VibWl0OiBmdW5jdGlvbihlKSB7XHJcbiAgICAgICAgICAgIHd4LnNob3dMb2FkaW5nKHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiAn5Yqg6L295LitJyxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgdmFyIG9iajIgPSB7XHJcbiAgICAgICAgICAgICAgICBcInRva2VuXCI6IHRoaXMudG9rZW4sXHJcbiAgICAgICAgICAgICAgICBcInRva2VuS2V5XCI6IHRoaXMudG9rZW5LZXksXHJcbiAgICAgICAgICAgICAgICBcInJlc3VtZWlkXCI6IHRoaXMucmVzdW1laWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZighb2JqMi5yZXN1bWVpZCl7XHJcbiAgICAgICAgICAgICAgICBkZWxldGUgb2JqMlsncmVzdW1laWQnXVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnN0IHRoYXQgPSB0aGlzO1xyXG4gICAgICAgICAgICB0aGlzLmNoYW5nZUJhc2VJbmZvKGUuZGV0YWlsLnZhbHVlLG9iajIpLnRoZW4oZGF0YT0+e1xyXG4gICAgICAgICAgICAgICAgaWYoZGF0YS5kYXRhICYmIGRhdGEuZGF0YS5yZXR1cm5Db2RlID09IFwiQUFBQUFBQVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd3gucmVkaXJlY3RUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybDogYHJlc3VtZT9yZXN1bWVpZD0ke3RoYXQucmVzdW1laWR9YFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgICAgICB0aXAuZXJyb3IoZGF0YS5kYXRhLnJldHVybk1zZyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB3eC5oaWRlTG9hZGluZygpXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfSxcclxuICAgICAgICBiaW5kUGlja2VyQ2hhbmdlMTogZnVuY3Rpb24oZSkge1xyXG4gICAgICAgICAgICB0aGlzLmpvYm5hdHVyZXN0YXR1cyA9IGZhbHNlIDtcclxuICAgICAgICAgICAgdGhpcy5pbmRleDEgPSBlLmRldGFpbC52YWx1ZTtcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJpbmRQaWNrZXJDaGFuZ2UyOiBmdW5jdGlvbihlKSB7XHJcbiAgICAgICAgICAgIHRoaXMucG9zdGlkc3N0YXR1cyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmluZGV4MiA9IGUuZGV0YWlsLnZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYmluZFBpY2tlckNoYW5nZTM6IGZ1bmN0aW9uKGUpIHtcclxuICAgICAgICAgICAgdGhpcy5zaXRlY2l0eXN0YXR1cyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmluZGV4MyA9IGUuZGV0YWlsLnZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYmluZFBpY2tlckNoYW5nZTQ6IGZ1bmN0aW9uKGUpIHtcclxuICAgICAgICAgICAgdGhpcy5leHBlY3RzYWxhcnljb2Rlc3RhdHVzID0gZmFsc2UgO1xyXG4gICAgICAgICAgICB0aGlzLmluZGV4NCA9IGUuZGV0YWlsLnZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYmluZFBpY2tlckNoYW5nZTU6IGZ1bmN0aW9uKGUpIHtcclxuICAgICAgICAgICAgdGhpcy5wb3N0c3RpbWVzdGF0dXMgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5pbmRleDUgPSBlLmRldGFpbC52YWx1ZTtcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy/ojrflj5bnroDljobln7rmnKzkv6Hmga9cclxuICAgIGFzeW5jIGdldEpvYkluZm8odG9rZW4sIHRva2VuS2V5LCByZXN1bWVpZCkge1xyXG4gICAgICAgIGNvbnN0IGpzb24gPSBhd2FpdCBhcGkuZ2V0UmVzdW1lSW5mbyh7XHJcbiAgICAgICAgcXVlcnk6IHtcclxuICAgICAgICAgICAgICAgIGhlYWQ6IHtcclxuICAgICAgICAgICAgICAgICAgICBcInRyYW5zY29kZVwiOiBcIk0wMDA0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiaFwiXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgICAgIFwidG9rZW5cIjogdG9rZW4sXHJcbiAgICAgICAgICAgICAgICAgICAgXCJ0b2tlbktleVwiOiB0b2tlbktleSxcclxuICAgICAgICAgICAgICAgICAgICBcInJlc3VtZWlkXCI6IHJlc3VtZWlkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgIHJldHVybiBqc29uO1xyXG4gICAgfVxyXG5cclxuICAgIC8v6I635Y+W5pWw5o2u5a2X5YW4XHJcbiAgICBhc3luYyBnZXREaWN0KGNvZGUpIHtcclxuICAgICAgICBjb25zdCBqc29uID0gYXdhaXQgYXBpLmdldERpY3REYXRhKHtcclxuICAgICAgICBxdWVyeToge1xyXG4gICAgICAgICAgICAgICAgaGVhZDoge1xyXG4gICAgICAgICAgICAgICAgICAgIFwidHJhbnNjb2RlXCI6IFwiREMwMDFcIixcclxuICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJoXCJcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgXCJncm91cGNvZGVcIjogY29kZSxcclxuICAgICAgICAgICAgICAgICAgICBcInNlbEFsbFwiOiBcInRydWVcIlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICByZXR1cm4ganNvbjtcclxuICAgIH1cclxuICAgIC8v5L+u5pS56KGo5Y2V5pWw5o2uXHJcbiAgICBhc3luYyBjaGFuZ2VCYXNlSW5mbyhvYmosb2JqMikge1xyXG4gICAgICAgIHZhciBkYXRhID0gb2JqMlxyXG4gICAgICAgIGZvciAodmFyIEtleSBpbiBvYmope1xyXG4gICAgICAgICAgICBpZighb2JqW0tleV0pe1xyXG4gICAgICAgICAgICAgICAgZGVsZXRlIG9ialtLZXldXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHJlc3VsdE9iaiA9IE9iamVjdC5hc3NpZ24oZGF0YSwgdGhpcy5qb2JBcHBseSwgb2JqKTtcclxuICAgICAgICBpZih0aGlzLmpvYmludGVudGNvZGUpe1xyXG4gICAgICAgICAgICByZXN1bHRPYmouam9iaW50ZW50Y29kZSA9IHRoaXMuam9iaW50ZW50Y29kZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QganNvbiA9IGF3YWl0IGFwaS5nZXRSZXN1bWVJbmZvKHtcclxuICAgICAgICBxdWVyeToge1xyXG4gICAgICAgICAgICAgICAgaGVhZDoge1xyXG4gICAgICAgICAgICAgICAgICAgIFwidHJhbnNjb2RlXCI6IFwiTTAwMTRcIixcclxuICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJoXCJcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBkYXRhOiByZXN1bHRPYmpcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgcmV0dXJuIGpzb247XHJcbiAgICB9XHJcbiAgfVxyXG4iXX0=