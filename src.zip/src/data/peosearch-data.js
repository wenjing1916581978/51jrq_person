const peoSearch = [
    "财务顾问",
    "投资经理",
    "产品经理",
    "web前端",
    "项目经理",
    "高级投资总监",
    "JAVA",
    "合规"
];
module.exports = peoSearch;