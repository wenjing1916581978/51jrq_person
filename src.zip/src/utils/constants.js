/**
 * @type {String}
 */
export const USER_OPERATE_INFO = "userSpecialInfo";

/**
 * 用户信息
 * @type {String}
 */
export const LOGIN_INFO = "loginInfo";

/**
 * @type {String}
 */
export const TECENT_MAP_KEY = 'R47BZ-7DD6U-23RVN-4J3QR-FOHUH-TJFAA';

/**
 * DESKEY
 * @type {String}
 */
export const DESKEY = '%!##@$%|$#$%(^)$}$*{^*+%';

